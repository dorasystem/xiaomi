<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('faqs.store')); ?>" method="POST" class="needs-validation" onsubmit="updateEditorContent()">
        <?php echo csrf_field(); ?>

        <main class="nxl-container">
            <div class="nxl-content">
                <div class="page-header">
                    <div class="page-header-left d-flex align-items-center">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Создать FAQ</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                            <li class="breadcrumb-item">FAQ</li>
                        </ul>
                    </div>
                    <div class="page-header-right ms-auto">
                        <button type="submit" class="btn btn-primary">Создать</button>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger m-3">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Детали FAQ</h5>
                                </div>
                                <div class="card-body p-4">
                                    <ul class="nav-tab-items-wrapper nav nav-justified invoice-overview-tab-item">
                                        <li class="nav-item">
                                            <a href="#uzContent" class="nav-link active" data-bs-toggle="tab" data-bs-target="#uzContent">O'zbekcha</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#enContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#enContent">English</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#ruContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#ruContent">Русский</a>
                                        </li>
                                    </ul>

                                    <div class="tab-content pt-3">
                                        <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade show <?php echo e($lang == 'uz' ? 'active' : ''); ?>" id="<?php echo e($lang); ?>Content">
                                                <div class="form-group pb-3">
                                                    <label for="question_<?php echo e($lang); ?>">Вопрос (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <input type="text" class="form-control" id="question_<?php echo e($lang); ?>" name="question_<?php echo e($lang); ?>" value="<?php echo e(old('question_' . $lang)); ?>" required>
                                                </div>
                                                <div class="form-group pb-3">
                                                    <label for="answer_<?php echo e($lang); ?>">Ответ (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <div id="editor_<?php echo e($lang); ?>" style="height:200px;"><?php echo old('answer_' . $lang); ?></div>
                                                    <input type="hidden" id="text_<?php echo e($lang); ?>" name="answer_<?php echo e($lang); ?>" value="<?php echo e(old('answer_' . $lang)); ?>">
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </form>

    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

    <script>
        <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        var editor<?php echo e(ucfirst($lang)); ?> = new Quill('#editor_<?php echo e($lang); ?>', { theme: 'snow' });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        function updateEditorContent() {
            <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            document.getElementById('text_<?php echo e($lang); ?>').value = editor<?php echo e(ucfirst($lang)); ?>.root.innerHTML;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/faqs/create.blade.php ENDPATH**/ ?>