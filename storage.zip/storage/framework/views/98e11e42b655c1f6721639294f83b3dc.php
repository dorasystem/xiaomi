<?php
$lang = \Illuminate\Support\Facades\App::getLocale();
?>
<?php $__env->startSection('content'); ?>
    <main class="container">
        <div class="my-4">
            <div class="d-flex align-items-center gap-3">
                <a href="/" class="text-grey fw-bold  fs-14"><?php echo app('translator')->get('home.home'); ?> / <span
                        class="text-dark"><?php echo app('translator')->get('home.useful_articles'); ?> </span></a>
            </div>
            <hr />
        </div>
        <div class="row d-sm-none d-flex align-items-center justify-content-between mb-lg-0 mb-2">

            <h2 class="order-lg-1 order-2 col-lg-10 fw-normal hover-orange mb-3">
                <?php echo e($articles['title_' . $locale] ?? ' '); ?></h2>
            <div class="order-lg-2 order-1 col-lg-2 d-flex align-items-center gap-2">
                <img src="/assets/icons/calendar-icon.svg" alt="" />
                <div class="text-grey"><?php echo e(\Carbon\Carbon::parse($articles['date'])->format('d.m.Y')); ?></div>
            </div>
        </div>
        <div class="col-12 pe-lg-5 pe-2 mb-4 d-sm-block d-none">
            <div class="newbanner w-100 rounded text-white d-flex flex-column justify-content-end"
                style="background-image: url('<?php echo e(asset('storage/' . $articles->image)); ?>'); height:500px;">
                <h1 class="mb-4">
                    <?php echo e($articles['title_' . $locale] ?? ' '); ?>

                </h1>
                <small class="fw-bold border-top pt-3">
                    <?php echo e(\Carbon\Carbon::parse($articles['date'])->format('d.m.Y')); ?></small>
            </div>
        </div>
        <div class="mb-5">
            <?php echo $articles['description_' . $locale]; ?>

            <br /><br />
            <?php echo $articles['content_' . $locale] ?? ' '; ?>

        </div>

        <?php if(!empty($otherNews) && $otherNews->count()): ?>
            <h1 class="fw-normal hover-orange mb-4 mt-5 text-history"><?php echo app('translator')->get('home.other_news'); ?></h1>
            <div style="overflow: hidden" class="news container py-3 position-relative">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $otherNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide product shadow-sm position-relative rounded">
                            <a href="<?php echo e(route('single.news', $item->slug)); ?>"
                                class="mb-3">
                                <img height="250px" class="w-100 fit-cover"
                                    src="<?php echo e(asset('storage/' . $item->image) ?? '/assets/images/news1.jpg'); ?>"
                                    alt="" />
                                <div class="p-4 bg-darkgrey">
                                    <div class="d-flex align-items-center gap-2">
                                        <img src="/assets/icons/calendar-icon.svg" alt="" />
                                        <div class="text-grey">
                                            <?php echo e(\Carbon\Carbon::parse($item->date)->format('d.m.Y')); ?></div>
                                    </div>
                                    <h4 class="fw-normal text-history"><?php echo e($item['title_' . $locale]); ?></h4>

                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Navigation buttons (optional) -->
                <div id="products-next" class="swiper-button-next end-0"></div>
                <div id="products-prev" class="swiper-button-prev start-0"></div>
            </div>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginal87286750868bd5ed726991ca65f5034f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87286750868bd5ed726991ca65f5034f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page.not-found','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page.not-found'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87286750868bd5ed726991ca65f5034f)): ?>
<?php $attributes = $__attributesOriginal87286750868bd5ed726991ca65f5034f; ?>
<?php unset($__attributesOriginal87286750868bd5ed726991ca65f5034f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87286750868bd5ed726991ca65f5034f)): ?>
<?php $component = $__componentOriginal87286750868bd5ed726991ca65f5034f; ?>
<?php unset($__componentOriginal87286750868bd5ed726991ca65f5034f); ?>
<?php endif; ?>
        <?php endif; ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/single-article.blade.php ENDPATH**/ ?>