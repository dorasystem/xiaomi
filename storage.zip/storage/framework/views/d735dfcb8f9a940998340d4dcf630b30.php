<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('contacts.update', $contact->id)); ?>" method="POST" enctype="multipart/form-data" novalidate class="needs-validation">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <main class="nxl-container">
            <div class="nxl-content">
                <div class="page-header">
                    <div class="page-header-left d-flex align-items-center">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Редактировать контакт</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                            <li class="breadcrumb-item">Контакты</li>
                        </ul>
                    </div>
                    <div class="page-header-right ms-auto">
                        <button type="submit" class="btn btn-primary">Сохранить</button>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger m-3">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Контактная информация</h5>
                                </div>
                                <div class="row card-body p-4">
                                    <div class="col-lg-4 col-md-4 form-group pb-3">
                                        <label for="email">Email:</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                               value="<?php echo e(old('email', $contact->email)); ?>" required>
                                    </div>
                                    <div class="col-lg-4 col-md-4 form-group pb-3">
                                        <label for="phone">Телефон:</label>
                                        <input type="text" class="form-control" id="phone" name="phone"
                                               value="<?php echo e(old('phone', $contact->phone)); ?>" required>
                                    </div>
                                    <div class="col-lg-4 col-md-4 form-group pb-3">
                                        <label for="address">Адрес:</label>
                                        <input type="text" class="form-control" id="address" name="address"
                                               value="<?php echo e(old('address', $contact->address)); ?>" required>
                                    </div>
                                    <div class="col-lg-4 col-md-4 form-group pb-3">
                                        <label for="facebook">Facebook:</label>
                                        <input type="url" class="form-control" id="facebook" name="facebook"
                                               value="<?php echo e(old('facebook', $contact->facebook)); ?>">
                                    </div>
                                    <div class="col-lg-4 col-md-4 form-group pb-3">
                                        <label for="instagram">Instagram:</label>
                                        <input type="url" class="form-control" id="instagram" name="instagram"
                                               value="<?php echo e(old('instagram', $contact->instagram)); ?>">
                                    </div>
                                    <div class="col-lg-4 col-md-4 form-group pb-3">
                                        <label for="telegram">Telegram:</label>
                                        <input type="url" class="form-control" id="telegram" name="telegram"
                                               value="<?php echo e(old('telegram', $contact->telegram)); ?>">
                                    </div>
                                    <div class="col-lg-4 col-md-4 form-group pb-3">
                                        <label for="youtube">YouTube:</label>
                                        <input type="url" class="form-control" id="youtube" name="youtube"
                                               value="<?php echo e(old('youtube', $contact->youtube)); ?>">
                                    </div>
                                    <div class="col-lg-4 col-md-4 form-group pb-3">
                                        <label for="linkedin">LinkedIn:</label>
                                        <input type="url" class="form-control" id="linkedin" name="linkedin"
                                               value="<?php echo e(old('linkedin', $contact->linkedin)); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/contacts/edit.blade.php ENDPATH**/ ?>