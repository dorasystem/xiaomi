<?php $__env->startSection('content'); ?>
    <main class="">
        <div class="container my-4 mb-5">
            <div class="d-flex align-items-center gap-3">
                <a href="/" class="text-grey fw-bold fs-14"><?php echo app('translator')->get('home.home'); ?> / <span
                        class="text-dark"><?php echo app('translator')->get('footer.about_us'); ?></span></a>
            </div>
            <hr />
            <h1 class="my-3 mb-5"><?php echo app('translator')->get('home.about_or_company'); ?></h1>
            <div class="row">
                <div class="col-md-12">
                    <div class="d-flex">
                        <div style="width: 7px" class="bg-orange me-5"></div>
                        <div style="font-family: Courier New" class="fs-4">
                            <?php echo $about['about_or_company_' . $lang]; ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="container my-5">
            <div class="row">
                <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6">
                        <h1 style="font-size: 50px" class="border-top border-3 pt-4 text-lightgrey fw-bold mt-3">
                            <?php echo e($history->year); ?></h1>
                        <div class="lh-normal text-black"><?php echo $history['description_' . $lang]; ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row my-5">
                <div class="col-md-6"><img style="object-position: right" class="w-100 rounded h-100 fit-cover"
                        src="<?php echo e(asset('storage/' . $about->image)); ?>" alt="" /></div>
                <div class="col-md-6 d-flex flex-column justify-content-start align-items-start gap-4">
                    <?php echo $about['description_' . $lang]; ?>

                </div>
            </div>
            <div class="row my-5">
                <div class="order-md-1 order-2 col-md-6 d-flex flex-column justify-content-start align-items-start gap-4">
                    <?php echo $about['content_' . $lang]; ?>

                </div>
                <div class="order-md-2 order-1 col-md-6"><img class="w-100 rounded h-100 fit-cover"
                        src="<?php echo e(asset('storage/' . $about->photo)); ?>" alt="" /></div>
            </div>
            <div class="row">
                <div class="row align-items-center justify-content-between">
                    <h1 class="col-md-8"><?php echo app('translator')->get('home.command'); ?></h1>

                </div>
                <?php if(!empty($careers) && $careers->count()): ?>
                    <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/career" class="col-md-3 col-sm-6 rounded mb-3">
                            <div class="bg-white rounded">
                                <img height="300" class="w-100 fit-cover"
                                    src="<?php echo e(asset('storage/' . $item->image) ?? '/assets/images/vacancy1.webp'); ?>"
                                    alt="" />
                                <div style="font-size: 11px" class="px-3 small fw-bold text-grey">
                                    <?php echo e($item['title_' . $lang]); ?></div>
                                <div class="px-3 pb-4 fw-semibold"><?php echo e($item['name_' . $lang]); ?></div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal87286750868bd5ed726991ca65f5034f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87286750868bd5ed726991ca65f5034f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page.not-found','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page.not-found'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87286750868bd5ed726991ca65f5034f)): ?>
<?php $attributes = $__attributesOriginal87286750868bd5ed726991ca65f5034f; ?>
<?php unset($__attributesOriginal87286750868bd5ed726991ca65f5034f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87286750868bd5ed726991ca65f5034f)): ?>
<?php $component = $__componentOriginal87286750868bd5ed726991ca65f5034f; ?>
<?php unset($__componentOriginal87286750868bd5ed726991ca65f5034f); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/about.blade.php ENDPATH**/ ?>