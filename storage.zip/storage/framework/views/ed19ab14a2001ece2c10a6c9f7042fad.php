<?php $__env->startSection('title', 'Список заказов'); ?>

<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <div class="nxl-content">
            <div class="page-header">
                <div class="page-header-left d-flex align-items-center">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Список заказов</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                        <li class="breadcrumb-item">Заказы</li>
                    </ul>
                </div>
            </div>
            <div class="main-content">

                <!-- Orders Table -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Заказы</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                            <tr>
                                <th scope="col">№</th>
                                <th scope="col">Имя клиента</th>
                                <th scope="col">Телефон</th>
                                <th scope="col">Message</th>
                                <th scope="col">Статус</th>
                                <th scope="col">Продукты</th>
                                <th scope="col" class="text-end">Действия</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></td>
                                    <td><?php echo e($order->phone); ?></td>
                                    <td> <?php echo e(\Illuminate\Support\Str::words($order->message, 5)); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('orders.update', $order->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <select name="status" onchange="this.form.submit()" class="form-select form-select-sm">
                                                <option value="new" <?php echo e($order->status === 'new' ? 'selected' : ''); ?>>Новый</option>
                                                <option value="processing" <?php echo e($order->status === 'processing' ? 'selected' : ''); ?>>В процессе</option>
                                                <option value="completed" <?php echo e($order->status === 'completed' ? 'selected' : ''); ?>>Завершён</option>
                                                <option value="cancelled" <?php echo e($order->status === 'cancelled' ? 'selected' : ''); ?>>Отменён</option>
                                            </select>
                                        </form>
                                    </td>
                                    <td>
                                        <table class="table table-sm table-bordered">
                                            <thead>
                                            <tr>
                                                <th>Название</th>
                                                <th>Количество</th>
                                                <th>Цена</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(\Illuminate\Support\Str::words($item->product->name_ru, 5)); ?></td>
                                                    <td><?php echo e($item->quantity); ?></td>
                                                    <td><?php echo e(number_format($item->price, 2)); ?> сум</td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('orders.edit', $order->id)); ?>"
                                               class="avatar-text avatar-md">
                                                <i class="feather feather-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="border-0 bg-transparent js-delete-btn" type="submit" onclick="return confirm('Вы действительно хотите удалить этот заказ?')">
                                                    <a href="javascript:void(0)" class="avatar-text avatar-md" data-bs-toggle="tooltip" data-bs-trigger="hover" title="Удалить">
                                                        <i class="feather-trash-2"></i>
                                                    </a>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($orders->isEmpty()): ?>
                        <div class="card-body">
                            <p class="text-center">На данный момент заказы отсутствуют.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>