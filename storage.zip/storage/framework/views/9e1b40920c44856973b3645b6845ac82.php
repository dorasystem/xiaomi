<?php
$lang = \Illuminate\Support\Facades\App::getLocale();
?>
<?php $__env->startSection('content'); ?>
    <main class="container">
        <div class="my-4">
            <div class="d-flex align-items-center gap-3">
                <a href="/" class="text-grey fw-bold  fs-14"><?php echo app('translator')->get('home.home'); ?> / <span
                        class="text-dark"><?php echo app('translator')->get('footer.news'); ?></span></a>
            </div>
            <hr />
        </div>
        <h1 class="fw-normal hover-orange mb-4 mt-4"><?php echo app('translator')->get('home.new_items'); ?> Xiaomi </h1>
        <div class="row">
            <?php if(!empty($news) && $news->count(0)): ?>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('single.news', $new->slug)); ?>"
                        class="col-md-4 col-sm-6 mb-3">
                        <img height="250px" class="w-100 fit-cover rounded-top"
                            src="<?php echo e(asset('storage/' . $new->image) ?? '/assets/images/news1.jpg'); ?>" alt="" />
                        <div class="p-4 bg-cardgrey rounded-bottom">
                            <div class="d-flex align-items-center gap-2">
                                <img src="/assets/icons/calendar-icon.svg" alt="" />
                                <div class="text-grey"> <?php echo e(\Carbon\Carbon::parse($new->date)->format('d.m.Y')); ?></div>
                            </div>
                            <h4 class="fw-normal">
                                <?php echo e($new['title_' . $lang] ?? 'Ожидаемый релиз: когда выйдет флагманская линейка Xiaomi 15'); ?>

                            </h4>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h2><?php echo app('translator')->get('home.no_other_news'); ?></h2>
            <?php endif; ?>
        </div>
        <h1 class="fw-normal hover-orange mb-4 mt-4"><?php echo app('translator')->get('home.useful_articles'); ?> </h1>
        <div class="row">
            <?php if(!empty($articles) && $articles->count(0)): ?>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('single.article', $item->slug)); ?>"
                        class="col-md-4 col-sm-6 mb-3">
                        <img height="250px" class="w-100 fit-cover rounded-top"
                            src="<?php echo e(asset('storage/' . $item->image) ?? '/assets/images/category_pilesos.webp'); ?>"
                            alt="" />
                        <div class="p-4 bg-cardgrey rounded-bottom">
                            <div class="d-flex align-items-center gap-2">
                                <img src="/assets/icons/calendar-icon.svg" alt="" />
                                <div class="text-grey"> <?php echo e(\Carbon\Carbon::parse($item->date)->format('d.m.Y')); ?></div>
                            </div>
                            <h4 class="fw-normal">
                                <?php echo e($item['title_' . $lang] ?? 'Ожидаемый релиз: когда выйдет флагманская линейка Xiaomi 15'); ?>

                            </h4>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h2><?php echo app('translator')->get('home.no_other_news'); ?></h2>
            <?php endif; ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/page-news.blade.php ENDPATH**/ ?>