 <?php $__env->slot('title', null, []); ?> Cart <?php $__env->endSlot(); ?>


<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <!-- introBannerHolder -->
        <section class="introBannerHolder d-flex w-100 bgCover"
                 style="background-image: url(/assets/images/b-bg7.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-12 pt-lg-23 pt-md-15 pt-sm-10 pt-6 text-center">
                        <h1 class="headingIV fwEbold playfair mb-4"><?php echo e(__('lan.my_cart')); ?></h1>
                        <ul class="list-unstyled breadCrumbs d-flex justify-content-center">
                            <li class="mr-sm-2 mr-1"><a href="/"><?php echo e(__('lan.home')); ?></a></li>
                            <li class="mr-sm-2 mr-1">/</li>
                            <li class="mr-sm-2 mr-1"><a href="<?php echo e(route('products.index')); ?>"><?php echo e(__('lan.store')); ?></a></li>
                            <li class="mr-sm-2 mr-1">/</li>
                            <li class="active"><?php echo e(__('lan.my_cart')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- cartHolder -->
        <div class="cartHolder container pt-xl-21 pb-xl-24 py-lg-20 py-md-16 py-10">
            <form action="<?php echo e(route('checkout')); ?>" method="POST" class="couponForm mb-md-0 mb-5 " >
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <!-- table-responsive -->
                    <div class="col-12 table-responsive mb-lg-20 mb-md-16 mb-5" style=" margin-bottom: 50px !important;">
                        <!-- cartTable -->
                        <table class="table cartTable mb-xl-22">
                            <thead>
                            <tr>
                                <th scope="col" class="text-uppercase fwEbold border-top-0"><?php echo e(__('lan.product_name')); ?></th>
                                <th scope="col" class="text-uppercase fwEbold border-top-0"><?php echo e(__('lan.price')); ?></th>
                                <th scope="col" class="text-uppercase fwEbold border-top-0"><?php echo e(__('lan.product_count')); ?></th>
                                <th scope="col" class="text-uppercase fwEbold border-top-0"><?php echo e(__('lan.total_price')); ?></th>
                                <th scope="col" class="text-uppercase fwEbold border-top-0"><?php echo e(__('lan.delete')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(session('cart')): ?>
                                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="align-items-center" data-id="<?php echo e($id); ?>">
                                        <!-- Mahsulot rasmi va nomi -->
                                        <td class="d-flex align-items-center border-top-0 border-bottom px-0 py-6">
                                            <div class="imgHolder">
                                                <img src="<?php echo e(asset('storage/'.$details['image'])); ?>"
                                                     alt="<?php echo e($details['name']); ?>" class="img-fluid">
                                            </div>
                                            <span class="title pl-2"><a href="#"><?php echo e($details['name']); ?></a></span>
                                        </td>
                                        <!-- Mahsulot narxi -->
                                        <td class="fwEbold border-top-0 border-bottom px-0 py-6 price"><?php echo e($details['price']); ?>

                                            $
                                        </td>
                                        <!-- Mahsulot sonini kiritish joyi -->
                                        <td class="border-top-0 border-bottom px-0 py-6">
                                            <input type="number" class="quantity" data-id="<?php echo e($id); ?>"
                                                   value="<?php echo e($details['quantity']); ?>" min="1">
                                        </td>
                                        <!-- Mahsulotning umumiy narxi -->
                                        <td class="fwEbold border-top-0 border-bottom px-0 py-6">
                                            <span class="total"><?php echo e($details['price'] * $details['quantity']); ?> $</span>
                                        </td>
                                        <!-- Mahsulotni o'chirish -->
                                        <td class="border-top-0 border-bottom px-0 py-6">
                                            <a href="javascript:void(0);"
                                               class="fas fa-times float-right remove-from-cart"
                                               data-id="<?php echo e($id); ?>"></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5"><?php echo e(__('lan.your_shopping_cart_is_empty')); ?></td>
                                </tr>
                                <tr>
                                    <td>               <a class="btn btnTheme w-100 fwEbold text-center text-white md-round py-3 px-4 py-md-3 px-md-4"  href="<?php echo e(route('products.index')); ?>" class="md-round d-block py-2 px-2"><?php echo e(__('lan.go_to_the_store')); ?></a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <p>
                        </p>
                    </div>
                </div>

                <div class="row d-flex justify-content-center align-items-center text-center">
                    <div class="col-12">
                            <div class="form-group mb-2">
                                <label for="name" class="fwEbold text-uppercase d-block mb-1"><?php echo e(__('lan.enter_your_name')); ?></label>
                                <input type="text"  name="name" id="name" class="form-control m-auto" required>
                            </div>
                    </div>
                    <div class="col-12">
                            <div class="form-group mb-4">
                                <label for="tel_number" class="fwEbold text-uppercase d-block mb-1"><?php echo e(__('lan.your_phone_number')); ?></label>
                                <input type="text" name="tel_number" id="tel_number" class="form-control m-auto" required>
                            </div>
                    </div>

                    <div class="col-12 col-md-6">
                        <div class="d-flex justify-content-between">
                            <strong class="txt fwEbold text-uppercase mb-1" ><?php echo e(__('lan.total_price')); ?></strong>
                            <strong class="price fwEbold text-uppercase mb-1"><span id="totalAmount"><?php echo e(array_sum(array_map(function($item) { return $item['price'] * $item['quantity']; }, session('cart', [])))); ?> $</span></strong>
                        </div>
                        <button type="submit"
                           class="btn btnTheme w-100 fwEbold text-center text-white md-round py-3 px-4 py-md-3 px-md-4">
                            <?php echo e(__('lan.proceed_to_checkout')); ?></button>
                    </div>
                </div>
            </form>


        </div>
        <div class="container mb-lg-24 mb-md-16 mb-10">
            <!-- subscribeSecBlock -->
        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            $(document).ready(function () {
                // Mahsulot miqdorini o'zgartirish
                $('.quantity').on('change', function () {
                    var id = $(this).data('id');
                    var quantity = $(this).val();
                    var price = parseFloat($(this).closest('tr').find('.price').text().replace('$', ''));

                    // Mahsulotning umumiy narxini yangilash
                    var total = price * quantity;
                    $(this).closest('tr').find('.total').text(total.toFixed(2) + ' $');

                    // Jami narxni yangilash
                    updateTotal();
                });

                // Jami narxni hisoblash funksiyasi
                function updateTotal() {
                    var totalAmount = 0;
                    $('.total').each(function () {
                        totalAmount += parseFloat($(this).text().replace('$', ''));
                    });
                    $('#totalAmount').text(totalAmount.toFixed(2) + ' $');
                }
            });

            $(document).ready(function () {
                // Mahsulotni savatdan o'chirish
                $('.remove-from-cart').on('click', function () {
                    let id = $(this).data('id');
                    $.ajax({
                        url: '<?php echo e(route("removeFromCart")); ?>',
                        method: "DELETE",
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            id: id
                        },
                        success: function (response) {
                            if (response.success) {
                                $('tr[data-id="' + id + '"]').remove();
                                $('#totalAmount').text(response.total + ' $');
                                window.location.reload()

                            }
                        }
                    });
                });
            });
        </script>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/dashboard/cart.blade.php ENDPATH**/ ?>