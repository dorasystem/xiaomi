
Salom Customer
<?php if(auth()->guard()->check()): ?>
    <form class="d-block" action="<?php echo e(route('logout')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" class="dropdown-item"><i class="feather-log-out"></i>
            Выйти
        </button>
    </form>
<?php endif; ?>
<?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/user/profile.blade.php ENDPATH**/ ?>