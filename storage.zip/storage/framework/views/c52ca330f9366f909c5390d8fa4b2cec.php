<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('categories.store')); ?>" method="POST" enctype="multipart/form-data" novalidate class="needs-validation">
        <?php echo csrf_field(); ?>

        <main class="nxl-container">
            <div class="nxl-content">
                <div class="page-header">
                    <div class="page-header-left d-flex align-items-center">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Создать категорию</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Категории</a></li>
                            <li class="breadcrumb-item">Создать категорию</li>
                        </ul>
                    </div>
                    <div class="page-header-right ms-auto">
                        <button type="submit" class="btn btn-primary">Создать</button>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger m-3">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Детали категории</h5>
                                </div>
                                <div class="card-body p-4">
                                    <ul class="nav-tab-items-wrapper nav nav-justified invoice-overview-tab-item">
                                        <li class="nav-item">
                                            <a href="#uzContent" class="nav-link active" data-bs-toggle="tab" data-bs-target="#uzContent">O'zbekcha</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#enContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#enContent">English</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#ruContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#ruContent">Русский</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content pt-3">
                                        <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade show <?php echo e($lang == 'uz' ? 'active' : ''); ?>" id="<?php echo e($lang); ?>Content">
                                                <div class="form-group pb-3">
                                                    <label for="name_<?php echo e($lang); ?>">Название (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <input type="text" class="form-control" id="name_<?php echo e($lang); ?>" name="name_<?php echo e($lang); ?>"
                                                           value="<?php echo e(old('name_' . $lang)); ?>" required>
                                                </div>
                                                <div class="form-group pb-3">
                                                    <label for="description_<?php echo e($lang); ?>">Описание (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <textarea class="form-control" id="description_<?php echo e($lang); ?>" name="description_<?php echo e($lang); ?>" rows="5"><?php echo e(old('description_' . $lang)); ?></textarea>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Дополнительно</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="form-group pb-3">
                                        <label for="image">Изображение категории:</label>
                                        <input type="file" class="form-control" id="image" name="image">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="icon">Изображение icon:</label>
                                        <input type="file" class="form-control" id="icon" name="icon">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="parent_id">Категория:</label>
                                        <select id="parent_id" name="parent_id" class="form-control">
                                            <option value="">-- Без родителя --</option> <!-- Ota kategoriya bo‘lmagan holat uchun -->
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"
                                                    <?php echo e(old('parent_id') == $category->id ? 'selected' : ''); ?>>
                                                    <?php echo e($category->name_ru); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/categories/create.blade.php ENDPATH**/ ?>