<?php
$lang = \Illuminate\Support\Facades\App::getLocale();
$isInCompare = in_array($product->id, session('compares', []));

?>

<?php $__env->startSection('content'); ?>
    <main>
        <div class="mt-4 container d-sm-block d-none">
            <div class="d-flex align-items-center gap-3">
                <a href="/" class="text-grey fw-bold  fs-14"><?php echo app('translator')->get('home.home'); ?> /
                    <a href="<?php echo e(route('products')); ?>" class="text-grey fw-bold text-lowercase fs-14">
                        <?php echo app('translator')->get('home.katalog'); ?> /
                    </a>
                    <span class="text-dark fw-bold text-lowercase fs-14"><?php echo e($product['name_' . $lang]); ?></span>
                </a>
            </div>
        </div>
        <!--Single prodtct  -->
        <div class="container mt-4">
            <div class="container border rounded-3 shadow-sm bg-white">
                <div class="row align-items-center justify-content-between border-bottom">
                    <div class="col-md-9 d-flex align-items-center gap-5 py-3">
                        <a href="<?php echo e(url()->previous()); ?>" class="d-lg-flex d-none align-items-center gap-2">
                            <img width="24px" style="transform: rotate(225deg)" src="/assets/icons/arrow.svg"
                                alt="" />
                            <span><?php echo app('translator')->get('home.back'); ?></span>
                        </a>
                        <div class="productName text-end fs-24"><?php echo e($product['name_' . $lang]); ?>

                            <?php echo e($product['color_' . $lang]); ?>

                        </div>
                    </div>
                    <div class="col-md-3 d-flex align-items-center justify-content-md-end gap-3">
                        <button onclick="toggleCompare(<?php echo e($product->id); ?>)"
                            class="w-100 my-md-0 my-2 bg-transparent px-3 justify-content-center py-1 d-flex align-items-center gap-3 border rounded-2">
                            

                            

                            <svg id="compare-icon-<?php echo e($product->id); ?>"
                                class="hover-svg <?php echo e(in_array($product->id, session('compares', [])) ? 'active-svg' : ''); ?>"
                                width="11" height="11" viewBox="0 0 11 11" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M8 3.5C8 3.22386 8.22386 3 8.5 3H10.5C10.7761 3 11 3.22386 11 3.5V10.5C11 10.7761 10.7761 11 10.5 11H8.5C8.22386 11 8 10.7761 8 10.5V3.5Z"
                                    fill="#000" />
                                <path
                                    d="M2.5 6H0.5C0.223858 6 0 6.22386 0 6.5V10.5C0 10.7761 0.223858 11 0.5 11H2.5C2.77614 11 3 10.7761 3 10.5V6.5C3 6.22386 2.77614 6 2.5 6Z"
                                    fill="#000" />
                                <path
                                    d="M6.5 0H4.5C4.22386 0 4 0.223858 4 0.5V10.5C4 10.7761 4.22386 11 4.5 11H6.5C6.77614 11 7 10.7761 7 10.5V0.5C7 0.223858 6.77614 0 6.5 0Z"
                                    fill="#000" />
                            </svg>

                            <span class="fs-14"><?php echo app('translator')->get('home.compare'); ?></span>
                        </button>
                        <button onclick="toggleFavourite(<?php echo e($product->id); ?>)"
                            class="w-100 my-md-0 my-2 bg-transparent fs-14 px-3 justify-content-center py-1 d-flex align-items-center gap-3 border rounded-2">
                            <i id="favourite-icon-<?php echo e($product->id); ?>"
                                class="fa-<?php echo e(in_array($product->id, session('favorites', [])) ? 'solid' : 'regular'); ?> <?php echo e(in_array($product->id, session('favorites', [])) ? 'text-orange' : ''); ?> fa-heart"></i>
                            <span class="fs-14"><?php echo app('translator')->get('home.save'); ?></span>
                        </button>
                    </div>
                </div>
                <div class="container p-0">
                    <div class="row">
                        <?php if(count($images) > 1): ?>
                            <div class="col-lg-1 thumbnail-images p-0 d-lg-block d-none"
                                style="overflow: auto; height: 610px">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button class="border p-0 bg-transparent" type="button"
                                        data-bs-target="#productCarousel" data-bs-slide-to="<?php echo e($key); ?>"
                                        <?php echo e($key === 0 ? 'aria-current="true"' : ''); ?>>
                                        <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="Image <?php echo e($key + 1); ?>"
                                            class="img-fluid <?php echo e($key === 0 ? 'little_active' : ''); ?>" />
                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <div class="col-lg-7 pt-5">
                            <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-inner">
                                    <?php if(count($images) > 0): ?>
                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="carousel-item <?php echo e($key === 0 ? 'active' : ''); ?>">
                                                <img src="<?php echo e(asset('storage/' . $image)); ?>" class="d-block w-100 h-100"
                                                    alt="Image <?php echo e($key + 1); ?>" />
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="carousel-item active">
                                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                                class="d-block w-100 h-100" alt="Default Image" />
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Chapga o'tish va O'ngga o'tish tugmalari faqat ko'rsatiladi agar 1 dan ko'p rasm bo'lsa -->
                                <?php if(count($images) > 1): ?>
                                    <button class="carousel-control-prev rounded-pill" type="button"
                                        data-bs-target="#productCarousel" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden"><?php echo app('translator')->get('home.previous'); ?></span>
                                    </button>

                                    <button class="carousel-control-next rounded-pill" type="button"
                                        data-bs-target="#productCarousel" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden"><?php echo app('translator')->get('home.next'); ?></span>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>


                        <!-- O'ng tarafdagi ma'lumotlar -->
                        <div class="col-lg-4 p-4 border-start">
                            <h6><?php echo e($product['name_' . $lang]); ?></h6>
                            <div class="fs-14">
                                <?php echo $product['description_' . $lang]; ?>

                            </div>

                            <?php if($variants->isEmpty() || !$variants->contains('storage', 'null')): ?>
                                <div class="text-grey mb-2 fs-14"><?php echo app('translator')->get('home.memory'); ?></div>
                            <?php endif; ?>
                            <div class="d-flex align-items-center gap-2 mb-3" id="storage-options">

                                <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($variants->isEmpty() || !$variants->contains('storage', 'null')): ?>
                                        <div style="cursor: pointer"
                                            class="fs-12 px-3 py-1 rounded storage-option bg-darkgrey"
                                            data-storage="<?php echo e($variant->storage); ?>" data-price="<?php echo e($variant->price); ?>"
                                            data-price-6="<?php echo e($variant->price_6); ?>"
                                            data-price-12="<?php echo e($variant->price_12); ?>"
                                            data-price-24="<?php echo e($variant->price_24); ?>">
                                            <?php echo e($variant->storage); ?>

                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                            <?php
                                function formatPrice($price) {
                                    return number_format($price, 0, '.', ' '); // Narxni "1 000 000" formatida chiqarish
                                }
                            ?>

                            <div class="fs-24 fw-bold mb-2" >
                                <?php echo e(number_format($variants->first()->price, 0, ',', ' ')); ?>  <span>UZS</span>
                            </div>
                            <div class="">
                                <div class="text-grey mb-2 fs-14"><?php echo app('translator')->get('home.installments'); ?></div>
                                <div class="text-center justify-content-center mb-3 fs-14 p-1 rounded bg-darkgrey border-orange installment-option"
                                     onclick="selectInstallmentOption(this)">
                                    <?php echo app('translator')->get('home.full_payment'); ?>
                                </div>
                                <div class="">
                                    <div class="d-flex gap-2 justify-content-center mb-3 fs-14 p-1 rounded bg-darkgrey price-6 installment-option"
                                         onclick="selectInstallmentOption(this)">
                                        <span class="text-orange">6</span> <?php echo app('translator')->get('home.month'); ?> <span
                                            class="text-orange"><?php echo e(formatPrice($variants->first()->price_6 ?? 0)); ?> UZS</span>
                                    </div>
                                    <div class="d-flex gap-2 justify-content-center mb-3 fs-14 p-1 rounded bg-darkgrey price-12 installment-option"
                                         onclick="selectInstallmentOption(this)">
                                        <span class="text-orange">12</span> <?php echo app('translator')->get('home.month'); ?> <span
                                            class="text-orange"><?php echo e(formatPrice($variants->first()->price_12 ?? 0)); ?> UZS</span>
                                    </div>
                                    <div class="d-flex gap-2 justify-content-center mb-3 fs-14 p-1 rounded bg-darkgrey price-24 installment-option"
                                         onclick="selectInstallmentOption(this)">
                                        <span class="text-orange">24</span> <?php echo app('translator')->get('home.month'); ?> <span
                                            class="text-orange"><?php echo e(formatPrice($variants->first()->price_24 ?? 0)); ?> UZS</span>
                                    </div>
                                </div>
                            </div>


                            <script>
                                function selectInstallmentOption(element) {
                                    // Barcha tanlangan variantlarga "bg-lightorange" va "border-orange" classlarini olib tashlash
                                    var allOptions = document.querySelectorAll('.installment-option');
                                    allOptions.forEach(function(option) {
                                        option.classList.remove('bg-lightorange', 'border-orange');
                                    });

                                    // Tanlangan variantga kerakli classlarni qo'shish
                                    element.classList.add('bg-lightorange', 'border-orange');
                                }
                            </script>

                            <hr />

                            <!-- Other UI elements... -->
                            <?php
                                $cheapestVariant = $product->variants->sortBy('price')->first();
                            ?>

                            <div class="d-flex flex-lg-row flex-column d-block align-items-center gap-3">
                                <button
                                    onclick="addToCart(<?php echo e($product->id); ?>, '<?php echo e($product['name_' . $lang]); ?>', <?php echo e($cheapestVariant->discount_price ?? $cheapestVariant->price); ?>, <?php echo e($cheapestVariant->id); ?>)"
                                    class="btn-orange rounded w-100"> <?php echo app('translator')->get('home.basket'); ?></button>
                                <button class="border-0 w-100 bg-darkgrey rounded py-2 px-3" data-bs-toggle="modal"
                                    data-bs-target="#largeModal" data-product-id="<?php echo e($product->id); ?>"
                                    data-product-name="<?php echo e($product['name_' . $lang]); ?>"
                                    data-product-price="<?php echo e($cheapestVariant->discount_price ?: $cheapestVariant->price); ?>"
                                    data-product-image="<?php echo e(asset('storage/' . $product->image)); ?>">
                                    <span><?php echo app('translator')->get('home.buy_now'); ?></span></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- product description -->
        <div class="container">
            <div class="border rounded-3 shadow-sm bg-white mt-5 p-md-5 p-3">
                <ul class="nav nav-tabs w-100 overflow-auto" id="aboutProduct" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="py-2 fs-14 ps-0 active" id="description-tab" data-bs-toggle="tab"
                            data-bs-target="#description" type="button" role="tab" aria-controls="description"
                            aria-selected="true"><?php echo app('translator')->get('home.desc'); ?></a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="py-2 fs-14" id="specifications-tab" data-bs-toggle="tab"
                            data-bs-target="#specifications" type="button" role="tab"
                            aria-controls="specifications" aria-selected="false"><?php echo app('translator')->get('home.specifications'); ?></a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="py-2 fs-14" id="installments-tab" data-bs-toggle="tab" data-bs-target="#installments"
                            type="button" role="tab" aria-controls="installments"
                            aria-selected="false"><?php echo app('translator')->get('home.installment'); ?></a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="py-2 fs-14" id="reviews-tab" data-bs-toggle="tab" data-bs-target="#reviews"
                            type="button" role="tab" aria-controls="reviews"
                            aria-selected="false"><?php echo app('translator')->get('home.review'); ?>
                            (<span><?php echo e($product->comments->count()); ?></span>)</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="py-2 fs-14 pe-0" id="delivery-tab" data-bs-toggle="tab" data-bs-target="#delivery"
                            type="button" role="tab" aria-controls="delivery"
                            aria-selected="false"><?php echo app('translator')->get('home.payment'); ?></a>
                    </li>
                </ul>

                <!-- Tab Content -->
                <div class="tab-content" id="aboutProductContent">
                    <div class="tab-pane fade show active" id="description" role="tabpanel"
                        aria-labelledby="description-tab">
                        <div class="pt-3 border-top container">
                            <div class="row align-items-center">
                                <?php $__currentLoopData = $descImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $descImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mt-4 col-lg-4 rounded-2">
                                        <img class="w-100 fit-cover rounded-top"
                                            src="<?php echo e(asset('storage/' . $descImage->image)); ?>" alt="" />
                                        <div class="bg-darkgrey p-4 rounded-bottom">
                                            <h6 class="fw-bold d-none">Интелектуальная система связи</h6>
                                            <div class="fs-sm-14">
                                                <?php echo e($descImage['description_' . $lang]); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="specifications" role="tabpanel" aria-labelledby="specifications-tab">
                        <div class="pt-3 border-top">
                            <style>
                                li strong::after {
                                    content: '';
                                    flex-grow: 1;
                                    border-bottom: 1px dotted #ccc;
                                    margin-left: 10px;
                                    white-space: nowrap;
                                }
                            </style>
                            <div style="display: flex;  margin-top: 20px;">
                                <div style="width: 100%; word-wrap: break-word; list-style:disc!important;  "
                                    class="str_replace">
                                    <?php echo str_replace('<br>', '', $product['content_' . $lang]); ?>

                                </div>
                            </div>


                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                        </div>
                    </div>

                    <div class="tab-pane fade" id="installments" role="tabpanel" aria-labelledby="installments-tab">
                        <div class="pt-3 border-top row align-items-start pb-5">
                            <div class="col-lg-6 order-lg-1 order-2 pt-5">
                                <?php echo app('translator')->get('home.inst_desc'); ?>
                            </div>
                            <div class="col-lg-6 order-lg-2 order-1 pt-5">
                                <img class="w-100" src="/assets/images/product-installment.png" alt="" />
                            </div>
                        </div>
                    </div>
                    <!-- reviews tab -->
                    <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
                        <div class="pt-3 border-top">
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mt-4">
                                    <div class=""><?php echo e($comment->name); ?> <?php echo e($comment->lastname); ?></div>
                                    <div class="d-flex align-items-center gap-3 my-2">
                                        <div class="d-flex align-items-center gap-1">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <img src="<?php echo e(asset($i <= $comment->rating ? 'assets/icons/star-orange.svg' : 'assets/icons/star-grey.svg')); ?>"
                                                    alt="" />
                                            <?php endfor; ?>
                                        </div>
                                        <div style="width: 1px; height: 15px; background-color: #bcc1caff"></div>
                                        <div class=""><?php echo e($comment->created_at->format('d F Y')); ?></div>
                                    </div>
                                    <div class="fs-14"><?php echo e($comment->message); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="mt-5">
                            <h1 class="fw-normal"><?php echo app('translator')->get('home.testimonials'); ?></h1>

                            <form id="comment-form" action="<?php echo e(route('comments.store')); ?>" method="POST"
                                class="container p-0">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="product-id" name="product_id" value="<?php echo e($product->id); ?>">

                                <div class="row justify-content-end">
                                    <div class="col-md-12 mb-3">
                                        <label for="rating" class="form-label"><?php echo app('translator')->get('home.rating'); ?></label>
                                        <div id="testimonials" class="rating d-flex justify-content-end">
                                            <?php for($i = 5; $i >= 1; $i--): ?>
                                                <input type="radio" name="rating" value="<?php echo e($i); ?>"
                                                    id="rating-<?php echo e($i); ?>" required />
                                                <label for="rating-<?php echo e($i); ?>">☆</label>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="testi_name" class="form-label"><?php echo app('translator')->get('home.name'); ?></label>
                                        <input type="text" class="form-control focus_none bg-grey py-2"
                                            id="testi_name" name="name" required />
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="testi_lastname" class="form-label"><?php echo app('translator')->get('home.lastname'); ?></label>
                                        <input type="text" class="form-control focus_none bg-grey py-2"
                                            id="testi_lastname" name="lastname" required />
                                    </div>
                                    <div class="col-12 mb-3">
                                        <label for="testi_message" class="form-label"><?php echo app('translator')->get('home.comment'); ?></label>
                                        <textarea class="form-control focus_none bg-grey py-2" id="testi_message" name="message" rows="3" required></textarea>
                                    </div>

                                    <div class="col-md-4">
                                        <button type="submit"
                                            class="btn-orange rounded w-100 mb-3 py-3"><?php echo app('translator')->get('home.send'); ?>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="delivery" role="tabpanel" aria-labelledby="delivery-tab">
                        <div class="container pt-3 border-top">
                            <div class="row">
                                <div class="col-lg-4 col-sm-6 mt-3">
                                    <div class="d-flex align-items-center gap-1 mb-3">
                                        <img width="30px" src="/assets/icons/yandex-logo.png" alt="" />
                                        <h6 class="text-orange mb-0"><?php echo app('translator')->get('home.title_des1'); ?></h6>
                                    </div>
                                    <div class="fs-14 mt-2 text-history fw-normal lh-22">
                                        <?php echo app('translator')->get('home.pay_des1'); ?>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6 mt-3">
                                    <div class="d-flex align-items-center gap-1 mb-3">
                                        <img width="30px" src="/assets/icons/truck-logo.svg" alt="" />
                                        <h6 class="text-orange mb-0"><?php echo app('translator')->get('home.title_des2'); ?></h6>
                                    </div>
                                    <div class="fs-14 mt-2 text-history fw-normal lh-22">
                                        <?php echo app('translator')->get('home.pay_des2'); ?> </div>
                                </div>
                                <div class="col-lg-4 col-sm-6 mt-3">
                                    <div class="d-flex align-items-center gap-1 mb-3">
                                        <img width="30px" src="/assets/icons/location-logo.svg" alt="" />
                                        <h6 class="text-orange mb-0"><?php echo app('translator')->get('home.title_des3'); ?></h6>
                                    </div>
                                    <div class="fs-14 mt-2 text-history fw-normal lh-22">
                                        <?php echo app('translator')->get('home.pay_des3'); ?>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6 mt-3">
                                    <div class="d-flex align-items-center gap-1 mb-3">
                                        <img width="30px" src="/assets/icons/payment-logo.svg" alt="" />
                                        <h6 class="text-orange mb-0"><?php echo app('translator')->get('home.title_des4'); ?></h6>
                                    </div>
                                    <div class="fs-14 mt-2 text-history fw-normal lh-22">
                                        <?php echo app('translator')->get('home.pay_des4'); ?>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6 mt-3">
                                    <div class="d-flex align-items-center gap-1 mb-3">
                                        <img width="30px" src="/assets/icons/bill-logo.svg" alt="" />
                                        <h6 class="text-orange mb-0"><?php echo app('translator')->get('home.title_des5'); ?></h6>
                                    </div>
                                    <div class="fs-14 mt-2 text-history fw-normal lh-22">
                                        <?php echo app('translator')->get('home.pay_des5'); ?> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- black banner -->
        <div class="banner py-5 mb-3 mt-5">
            <div class="container">
                <div class="d-flex justify-content-between advantages py-4 gap-5">
                    <div class="d-flex flex-column gap-3 align-items-center">
                        <img src="/assets/icons/check-icon.svg" alt="" />
                        <div class="text-center text-nowrap"><span class="fw-bold">Xiaomi</span>
                            <br /><?php echo app('translator')->get('home.authorized_store'); ?>
                        </div>
                    </div>
                    <div class="d-flex flex-column align-items-center">
                        <img src="/assets/icons/truck-icon.svg" alt="" />
                        <div class="text-center text-nowrap">
                            <span class="fw-bold"><?php echo app('translator')->get('home.delivery'); ?></span> <br />
                            <?php echo app('translator')->get('home.all_over_uzbekistan'); ?>
                        </div>
                    </div>
                    <div class="d-flex flex-column gap-3 align-items-center">
                        <img src="/assets/icons/shop-icon.svg" alt="" />
                        <div class="text-center text-nowrap">
                            <span class="fw-bold"><?php echo app('translator')->get('home.pickup'); ?></span> <br />
                            <?php echo app('translator')->get('home.from_the_nearest_store'); ?>
                        </div>
                    </div>
                    <div class="d-flex flex-column gap-3 align-items-center">
                        <img src="/assets/icons/calendar.svg" alt="" />
                        <div class="text-center text-nowrap">
                            <span class="fw-bold"><?php echo app('translator')->get('home.favorable_installment_plan'); ?></span> <br />
                            <?php echo app('translator')->get('home.without_prepayment'); ?>
                        </div>
                    </div>
                    <div class="d-flex flex-column gap-3 align-items-center">
                        <!-- <img src="./assets/icons/tools.svg" alt="" /> -->
                        <img src="/assets/icons/settings.svg" alt="" />
                        <div class="text-center text-nowrap">
                            <span class="fw-bold"><?php echo app('translator')->get('home.free'); ?></span> <br />
                            <?php echo app('translator')->get('home.device_setup'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Similar products -->
        <div style="overflow: hidden" class="similarProducts container py-3 mb-5 position-relative">
            <div class="d-flex align-items-center justify-content-between mt-5">
                <div class="mb-4 fs-2 fw-bold"><?php echo app('translator')->get('home.similar_product'); ?></div>
                <div class="">
                    <a href="<?php echo e(route('products')); ?>"
                        class="view_all_btn text-orange border-0 bg-transparent mb-4"><?php echo app('translator')->get('home.smartphonesAll'); ?></a>
                    <svg width="16" height="16" viewBox="0 0 23 23" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_43_12)">
                            <path
                                d="M18.176 5.27026L17.4665 5.2797L8.88696 5.59498L8.83354 7.04846L15.6796 6.79436L5.18161 17.2924L6.15388 18.2647L16.6514 7.76716L16.3989 14.6117L17.8523 14.5583L18.1676 5.97869L18.176 5.27026Z"
                                fill="#ff6700" />
                        </g>
                        <defs>
                            <clipPath id="clip0_43_12">
                                <rect width="13" height="18.1071" fill="white"
                                    transform="translate(13.752 0.501953) rotate(45)" />
                            </clipPath>
                        </defs>
                    </svg>
                </div>
            </div>
            
            <?php if (isset($component)) { $__componentOriginal6cce5001eb94376a54fb3597dd93e058 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cce5001eb94376a54fb3597dd93e058 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page.product.product-slide','data' => ['productId' => $product->id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page.product.product-slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['productId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cce5001eb94376a54fb3597dd93e058)): ?>
<?php $attributes = $__attributesOriginal6cce5001eb94376a54fb3597dd93e058; ?>
<?php unset($__attributesOriginal6cce5001eb94376a54fb3597dd93e058); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cce5001eb94376a54fb3597dd93e058)): ?>
<?php $component = $__componentOriginal6cce5001eb94376a54fb3597dd93e058; ?>
<?php unset($__componentOriginal6cce5001eb94376a54fb3597dd93e058); ?>
<?php endif; ?>

            
            <!-- Navigation buttons (optional) -->
            <div id="product-next" class="swiper-button-next end-0"></div>
            <div id="product-prev" class="swiper-button-prev start-0"></div>
        </div>
        <!-- contact -->
        <?php if (isset($component)) { $__componentOriginal7e895d4daace1a259112e25cf0a67578 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e895d4daace1a259112e25cf0a67578 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page.contact','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page.contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e895d4daace1a259112e25cf0a67578)): ?>
<?php $attributes = $__attributesOriginal7e895d4daace1a259112e25cf0a67578; ?>
<?php unset($__attributesOriginal7e895d4daace1a259112e25cf0a67578); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e895d4daace1a259112e25cf0a67578)): ?>
<?php $component = $__componentOriginal7e895d4daace1a259112e25cf0a67578; ?>
<?php unset($__componentOriginal7e895d4daace1a259112e25cf0a67578); ?>
<?php endif; ?>
    </main>

    <div id="overlay"></div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const storageOptions = document.querySelectorAll('.storage-option');
            const priceDisplay = document.getElementById('price-display');

            function updatePriceAndHighlight(option) {
                const price = option.getAttribute('data-price');

                // Update the price display
                priceDisplay.innerHTML = `${price} <span>UZS</span>`;

                // Reset background color for all options
                storageOptions.forEach(function(opt) {
                    opt.classList.remove('bg-lightorange');
                    opt.classList.add('bg-darkgrey');
                    opt.classList.remove('border-orange');

                });

                option.classList.remove('bg-darkgrey');
                option.classList.add('border-orange');
            }

            // Set the default active storage option (4/256 ГБ)
            updatePriceAndHighlight(storageOptions[0]);

            // Add event listeners to each storage option
            storageOptions.forEach(function(option) {
                option.addEventListener('click', function() {
                    updatePriceAndHighlight(option);
                });
            });
        });

        function addToCart(productId, productName, productPrice, variantId) {
            $.ajax({
                url: `/add-to-cart`,
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    product_id: productId,
                    variant_id: variantId,
                    price: productPrice,
                    storage: 1,
                },
                success: function(response) {
                    if (response.success) {
                        updateCartCount(response.cart_count);

                        // Bootstrap toast xabarni ko'rsatish
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();
                    } else {
                        alert('Xatolik yuz berdi: ' + response.message);
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                }
            });
        }

        function updateCartCount(count) {
            document.getElementById('cart-count').innerText = count; // Updates the cart count badge
        }

        function toggleFavourite(productId) {
            $.ajax({
                url: '/toggle-favorite',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: productId
                },
                success: function(response) {
                    if (response.success) {
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();

                        // Sevimlilar sonini yangilash
                        $('#favorite-count').text(response.favorites_count);

                        // Ico'ni yangilash
                        if (response.message.includes('qo\'shildi')) {
                            $('#favourite-icon-' + productId).addClass('text-orange');
                            if (document.getElementById('favourite-icon-' + productId).classList.contains(
                                    "fa-regular")) {
                                document.getElementById('favourite-icon-' + productId).classList.remove(
                                    'fa-regular')
                                document.getElementById('favourite-icon-' + productId).classList.add('fa-solid')
                            }
                        } else {
                            $('#favourite-icon-' + productId).removeClass(
                                'text-orange'); // O'chirilganini ko'rsatish
                            if (document.getElementById('favourite-icon-' + productId).classList.contains(
                                    "fa-solid")) {
                                document.getElementById('favourite-icon-' + productId).classList.remove(
                                    'fa-solid')
                                document.getElementById('favourite-icon-' + productId).classList.add(
                                    'fa-regular')
                            }
                        }
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                }
            });
        }

        function toggleCompare(productId) {
            $.ajax({
                url: '/toggle-compare',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: productId
                },
                success: function(response) {
                    if (response.success) {
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();

                        // Sevimlilar sonini yangilash
                        $('#compare-count').text(response.compares_count); // Id bo'yicha o'zgarish

                        // Ico'ni yangilash
                        if (response.message.includes('qo\'shildi')) {
                            $('#compare-icon-' + productId).addClass(
                                'active-svg'); // Qo'shilganini ko'rsatish
                        } else {
                            $('#compare-icon-' + productId).removeClass(
                                'active-svg'); // O'chirilganini ko'rsatish
                        }
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                }
            });
        }
    </script>
    <style>
        .str_replace ul li {
            list-style-type: disc !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/single-product.blade.php ENDPATH**/ ?>