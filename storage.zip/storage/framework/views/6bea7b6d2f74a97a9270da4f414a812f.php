<?php $__env->startSection('content'); ?>
    <main class="">
        <!-- contact -->
        <div class="container my-4">
            <div class="d-flex align-items-center gap-3">
                <a href="/" class="text-grey fw-bold  fs-14"><?php echo app('translator')->get('home.home'); ?> / <span class="text-dark"><?php echo app('translator')->get('footer.contacts'); ?></span></a>
            </div>
            <hr />
        </div>
        <?php if (isset($component)) { $__componentOriginal7e895d4daace1a259112e25cf0a67578 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e895d4daace1a259112e25cf0a67578 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page.contact','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page.contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e895d4daace1a259112e25cf0a67578)): ?>
<?php $attributes = $__attributesOriginal7e895d4daace1a259112e25cf0a67578; ?>
<?php unset($__attributesOriginal7e895d4daace1a259112e25cf0a67578); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e895d4daace1a259112e25cf0a67578)): ?>
<?php $component = $__componentOriginal7e895d4daace1a259112e25cf0a67578; ?>
<?php unset($__componentOriginal7e895d4daace1a259112e25cf0a67578); ?>
<?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/contact.blade.php ENDPATH**/ ?>