<?php
use App\Models\Store;
$lang = app()->getLocale();
$locations = Store::all();
?>

<div class="container">
    <div class="row">
        <div class="col-lg-6 pt-5 pe-lg-5 pe-2">
            <h1 class="mb-4"><?php echo app('translator')->get('home.our_shops'); ?></h1>
            <!-- Tabs Navigation -->
            <ul class="border-0 flex-wrap ps-0 nav-tabs gap-3 addresses mb-0" id="tabsNavigation" role="tablist">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item" role="presentation">
                        <button
                            class="locationtab d-flex gap-4 align-items-center w-100 border-0 border-top py-4 bg-transparent <?php echo e($key === 0 ? 'active' : ''); ?>"
                            id="tab<?php echo e($location->id); ?>-button" data-bs-toggle="tab"
                            data-bs-target="#tab<?php echo e($location->id); ?>-content" type="button" role="tab"
                            aria-controls="tab<?php echo e($location->id); ?>-content"
                            aria-selected="<?php echo e($key === 0 ? 'true' : 'false'); ?>">
                            <div class="shop-icon p-2 rounded"><i class="fa-solid fa-shop"></i></div>
                            <div class="d-flex flex-column align-items-start">
                                <h5><?php echo e($location['address_' . $lang]); ?></h5>
                                <div><?php echo e($location['title_' . $lang]); ?></div>
                            </div>
                        </button>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="col-lg-6">
            <!-- Tabs Content -->
            <div class="tab-content" id="tabsContent">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade <?php echo e($key === 0 ? 'show active' : ''); ?>"
                         id="tab<?php echo e($location->id); ?>-content"
                         role="tabpanel"
                         aria-labelledby="tab<?php echo e($location->id); ?>-button">
                        <div id="map<?php echo e($location->id); ?>" class="map-container"></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<script>
    // for map
    const locations = <?php echo json_encode($locations, 15, 512) ?>;

    const mapConfigs = locations.map(location => ({
        container: `map${location.id}`,
        coordinates: [parseFloat(location.latitude), parseFloat(location.longitude)],
        zoom: 12,
        markerImage: "https://cdn-icons-png.flaticon.com/512/684/684908.png"
    }));

    ymaps.ready(() => {
        mapConfigs.forEach((config) => {
            const map = new ymaps.Map(config.container, {
                center: config.coordinates,
                zoom: config.zoom,
            });

            const customPlacemark = new ymaps.Placemark(
                config.coordinates, {}, {
                    iconLayout: "default#image",
                    iconImageHref: config.markerImage,
                    iconImageSize: [40, 40],
                    iconImageOffset: [-20, -20],
                }
            );

            map.geoObjects.add(customPlacemark);
        });
    });
</script>
<?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/components/page/contact.blade.php ENDPATH**/ ?>