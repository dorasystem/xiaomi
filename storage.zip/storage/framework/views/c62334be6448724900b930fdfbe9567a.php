<?php $__env->startSection('title', 'Список контактов'); ?>

<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <div class="nxl-content">
            <div class="page-header">
                <div class="page-header-left d-flex align-items-center">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Список контактов</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                        <li class="breadcrumb-item">Контакты</li>
                    </ul>
                </div>
            </div>
            <div class="main-content">

                <!-- Contacts Table -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Контакты</h5>
                    </div>
                    <div class="table-responsive mb-2" style="overflow-x: auto;">
                        <table class="table">
                            <thead class="">
                            <tr>
                                <th scope="col">№</th>
                                <th scope="col">Email</th>
                                <th scope="col">Телефон</th>
                                <th scope="col">Адрес</th>
                                <th scope="col">Facebook</th>
                                <th scope="col">Instagram</th>
                                <th scope="col">Telegram</th>
                                <th scope="col">Youtube</th>
                                <th scope="col">LinkedIn</th>
                                <th scope="col" class="text-end">Действия</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->phone); ?></td>
                                    <td><?php echo e($item->address); ?></td>
                                    <td>
                                        <?php if($item->facebook): ?>
                                            <a href="<?php echo e($item->facebook); ?>" target="_blank">Facebook</a>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->instagram): ?>
                                            <a href="<?php echo e($item->instagram); ?>" target="_blank">Instagram</a>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->telegram): ?>
                                            <a href="<?php echo e($item->telegram); ?>" target="_blank">Telegram</a>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td><td>
                                        <?php if($item->youtube): ?>
                                            <a href="<?php echo e($item->youtube); ?>" target="_blank">Youtube</a>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td><td>
                                        <?php if($item->linkedin): ?>
                                            <a href="<?php echo e($item->lnkedin); ?>" target="_blank">LinkedIn</a>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('contacts.edit', $item->id)); ?>"
                                               class="avatar-text avatar-md">
                                                <i class="feather feather-edit"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($contacts->isEmpty()): ?>
                        <div class="card-body">
                            <p class="text-center">На данный момент контакты отсутствуют.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/contacts/index.blade.php ENDPATH**/ ?>