<?php $__env->startSection('content'); ?>
    <main class="container">
        <div class="my-4">
            <div class="d-flex align-items-center gap-3">
                <a href="/" class="text-grey fw-bold  fs-14"><?php echo app('translator')->get('home.home'); ?> / <span
                        class="text-dark"><?php echo app('translator')->get('footer.blog'); ?></span></a>
            </div>
            <hr />
        </div>
        <div style="background-image: url('<?php echo e(asset('storage/' . $blog->image)); ?>')" class="blogbanner rounded w-100 my-3 py-5 d-flex align-items-center">
            <div class="col-sm-4 col-8">
                <div class="text-grey"><?php echo app('translator')->get('home.reviews'); ?></div>
                <h2 class="fw-bold"><?php echo e($blog['title_' . $lang]); ?></h2>
                <div class="d-flex align-items-center gap-4 mb-3">
                    <div class="text-grey"><?php echo e(\Carbon\Carbon::parse($blog->date)->format('d.m.Y')); ?></div>
                    
                </div>
                <a href="<?php echo e(route('single.blog', $blog->slug)); ?>">
                    <button class="border-1 rouned rounded text-uppercase py-1 px-4 bg-transparent"><?php echo app('translator')->get('home.read'); ?></button>
                </a>
            </div>
        </div>
        <div class="row mt-5">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('single.blog', $blog->slug)); ?>"
                    class="col-lg-3 col-md-4 col-sm-6 mb-4">
                    <img height="220px" class="mb-2 w-100 rounded-top fit-cover"
                        src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="<?php echo e($blog['title_' . $lang]); ?>" />

                    <div class="text-grey fs-14">Обзоры</div>
                    <h6 class="fw-bold"><?php echo e($blog['title_' . $lang]); ?></h6>
                    <div class="d-flex align-items-center gap-4 mb-3 fs-14">
                        <div class="text-grey"><?php echo e(\Carbon\Carbon::parse($blog->date)->format('d.m.Y')); ?></div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/page-blog.blade.php ENDPATH**/ ?>