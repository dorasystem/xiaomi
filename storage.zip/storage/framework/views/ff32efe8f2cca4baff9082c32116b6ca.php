<?php
$lang = app()->getLocale();
?>
<main class="text-light-black fs-14 fs-12-responsive mt-responsive dr-text">
    <div class="container ">
        <div class="d-flex align-items-center  flex-wrap mt-4 w-100">
            <div class=" col-md-6 d-flex flex-column align-items center justify-content-center gap-3 w-100 text-center">
                <h3 class=""><?php echo app('translator')->get('home.not_found'); ?></h3>
                <a class="" href="/">
                    <button type="button" class="btn-orange text-white border-0 rounded p-15-28 ">
                        <?php echo app('translator')->get('home.go_to_home'); ?>
                    </button>
                </a>
            </div>
        </div>
    </div>
</main>
<?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/components/page/not-found.blade.php ENDPATH**/ ?>