<?php $__env->startSection('content'); ?>
    <main class="container">
        <div class="my-4">
            <div class="d-flex align-items-center gap-3">
                <a href="/" class="text-grey fw-bold  fs-14"><?php echo app('translator')->get('home.home'); ?> / <span
                        class="text-dark"><?php echo app('translator')->get('home.page_not_found'); ?></span></a>
            </div>
            <hr />
        </div>
        <main class="">
            <div class="container ">
                <div class="row mt-4 mt-lg-0">
                    <div class=" col-md-6 d-flex flex-column align-items-center justify-content-center gap-3">
                        <h3 class="dr-text"><?php echo app('translator')->get('home.page_not_found'); ?></h3>
                        <div class="">
                            <a href="<?php echo e(route('home')); ?>" type="button"
                                class="btn-orange rounded w-100 d-flex align-items-center gap-2 px-4 justify-content-center">
                                <?php echo app('translator')->get('home.go_to_home'); ?>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="">
                            <img class="fit-cover" width="350px" src="/assets/images/not-found.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/errors-404.blade.php ENDPATH**/ ?>