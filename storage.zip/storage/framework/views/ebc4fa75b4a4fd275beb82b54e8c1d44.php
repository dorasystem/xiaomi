<?php $__env->startSection('content'); ?>
    <main class="container">
        <div class="my-4">
            <div class="d-flex align-items-center gap-1">
                <a href="/" class="text-grey fw-bold  fs-14"><?php echo app('translator')->get('home.home'); ?> /</a> <span
                    class="text-dark fw-bold"><?php echo app('translator')->get('home.compare'); ?></span>
            </div>
            <hr />
        </div>
        <div class="container  p-0">
            <h1 class="m-0 fs-2 fw-normal container"><?php echo app('translator')->get('home.compare'); ?></h1>
            <?php if(!empty($categoriesWithProducts) && $products->count()): ?>
                <div class="d-lg-flex align-items-center justify-content-between d-block container">
                    <div class="col-lg-9 d-flex flex-column gap-4 my-3 align-items-start">
                        <ul class="nav nav-tabs mb-1 overflow-auto w-100" id="myTab" role="tablist"
                            style="white-space: nowrap">
                            <?php $__currentLoopData = $categoriesWithProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="me-3 mb-3" role="presentation">
                                    <a class="fs-5 p-2 <?php if($loop->first): ?> active <?php endif; ?>"
                                        id="products<?php echo e($item['category']->id); ?>-tab" data-bs-toggle="tab"
                                        href="#products<?php echo e($item['category']->id); ?>" role="tab"
                                        aria-controls="products<?php echo e($item['category']->id); ?>"
                                        aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                                        <?php echo e($item['category']['name_' . $lang]); ?>

                                        <span>(<?php echo e($item['products']->count()); ?>)</span>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="tab-content container" id="myTabContent">
                    <?php $__currentLoopData = $categoriesWithProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>"
                            id="products<?php echo e($item['category']->id); ?>" role="tabpanel"
                            aria-labelledby="products<?php echo e($item['category']->id); ?>-tab">
                            <div class="row">
                                <?php $__currentLoopData = $item['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                                        <div class="product shadow-sm position-relative rounded">
                                            <div class="">
                                                <div
                                                    class="position-absolute like d-flex flex-column gap-3 justify-content-end">
                                                    <a href="javascript:void(0);"
                                                        onclick="toggleFavourite(<?php echo e($product->id); ?>)">
                                                        <i id="favourite-icon-<?php echo e($product->id); ?>"
                                                            class="fa-<?php echo e(in_array($product['id'], session('favorites', [])) ? 'solid' : 'regular'); ?> <?php echo e(in_array($product->id, session('favorites', [])) ? 'text-orange' : 'hover-orange'); ?> fa-heart fs-4 ps-1"></i>
                                                    </a>

                                                    <a onclick="toggleCompare(<?php echo e($product->id); ?>)">
                                                        <svg id="compare-icon-<?php echo e($product->id); ?>"
                                                            class="hover-svg <?php echo e(in_array($product->id, session('compares', [])) ? 'active-svg' : ''); ?>"
                                                            width="30" height="20" viewBox="0 0 102 92"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <rect width="11" height="92" rx="2"
                                                                fill="#000" />
                                                            <rect x="23" y="22" width="11" height="70" rx="2"
                                                                fill="#000" />
                                                            <rect x="46" y="45" width="11" height="47" rx="2"
                                                                fill="#000" />
                                                            <rect x="69" y="23" width="11" height="69" rx="2"
                                                                fill="#000" />
                                                            <rect x="91" y="45" width="11" height="47" rx="2"
                                                                fill="#000" />
                                                        </svg>
                                                    </a>
                                                </div>
                                                <?php
                                                    $cheapestVariant = $product->variants->sortBy('price')->first();
                                                ?>
                                                <a href="<?php echo e(route('single.product', $product->slug)); ?>">
                                                    <img class="w-100 pb-4 productImage p-4"
                                                        src="<?php echo e(asset('storage/' . $product->image) ?? '/assets/images/category_tv.webp'); ?>"
                                                        alt="" />
                                                </a>
                                                <div style="height: 200px"
                                                    class="d-flex flex-column justify-content-between bg-white p-4 rounded-bottom">
                                                    <div class="d-flex align-items-end gap-3 pt-2">
                                                        <?php if($cheapestVariant->discount_price): ?>
                                                            <div class="fw-bold ">
                                                                <?php echo e(number_format($cheapestVariant->discount_price, 0, ',', ' ')); ?>

                                                                UZS
                                                            </div>
                                                            <del class="text-grey">
                                                                <small><?php echo e(number_format($cheapestVariant->price, 0, ',', ' ')); ?>

                                                                    UZS</small>
                                                            </del>
                                                        <?php else: ?>
                                                            <div class="fw-bold">
                                                                <?php echo e(number_format($cheapestVariant->price, 0, ',', ' ')); ?>

                                                                UZS
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <a href="<?php echo e(route('single.product', $product->slug)); ?>">
                                                        <div class="productName fw-bold">
                                                            <?php echo e(\Str::words($product['name_' . $lang], 3)); ?></div>
                                                    </a>
                                                    <div class="d-flex align-items-center justify-content-between w-100">
                                                        <span class="small bg-transparent px-0">
                                                            <?php if($cheapestVariant->discount_price): ?>
                                                                <?php echo e(number_format($cheapestVariant->discount_price, 0, ',', ' ')); ?>

                                                                UZS
                                                            <?php else: ?>
                                                                <small><?php echo e(number_format($cheapestVariant->price, 0, ',', ' ')); ?>

                                                                    UZS</small>
                                                            <?php endif; ?>
                                                            <span class="text-orange"><?php echo app('translator')->get('home.incash'); ?></span>
                                                        </span>
                                                        <span
                                                            class="px-2 productmonth-border small text-grey"><?php echo e(number_format($cheapestVariant->price_12, 0, ',', ' ')); ?>

                                                            UZS/<?php echo app('translator')->get('home.month'); ?></span>
                                                    </div>

                                                    <div class="d-flex gap-4 mt-3">
                                                        <a class="border-orange bg-transparent rounded p-1 px-3"
                                                            href="javascript: void(0);" type="button"
                                                            onclick="addToCart(<?php echo e($product->id); ?>, '<?php echo e($product['name_' . $lang]); ?>', <?php echo e($cheapestVariant->discount_price ?? $cheapestVariant->price); ?>, <?php echo e($cheapestVariant->id); ?>)">
                                                            <img src="/assets/icons/shopping-cart.svg" alt="" />
                                                        </a>
                                                        <button data-bs-toggle="modal" data-bs-target="#largeModal"
                                                            class="btn-orange rounded w-100 d-flex align-items-center gap-2 justify-content-center"
                                                            data-product-id="<?php echo e($product->id); ?>"
                                                            data-product-name="<?php echo e($product['name_' . $lang]); ?>"
                                                            data-product-price="<?php echo e($cheapestVariant->discount_price ?: $cheapestVariant->price); ?>"
                                                            data-product-image="<?php echo e(asset('storage/' . $product->image)); ?>">
                                                            <span><?php echo app('translator')->get('home.buy_now'); ?></span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="text-center">
                    <img width="350px" src="/assets/images/not-found.png" alt="">
                </div>
                <?php if (isset($component)) { $__componentOriginal87286750868bd5ed726991ca65f5034f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87286750868bd5ed726991ca65f5034f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page.not-found','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page.not-found'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87286750868bd5ed726991ca65f5034f)): ?>
<?php $attributes = $__attributesOriginal87286750868bd5ed726991ca65f5034f; ?>
<?php unset($__attributesOriginal87286750868bd5ed726991ca65f5034f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87286750868bd5ed726991ca65f5034f)): ?>
<?php $component = $__componentOriginal87286750868bd5ed726991ca65f5034f; ?>
<?php unset($__componentOriginal87286750868bd5ed726991ca65f5034f); ?>
<?php endif; ?>

                <div style="overflow: hidden" class="seenProducts container py-3 px-0 position-relative">
                    <div class="mb-4 fs-2 fw-bold"><?php echo app('translator')->get('home.top_products'); ?></div>

                    <div class="container py-5">
                        <div class="row g-4">
                            <?php $__currentLoopData = $allPategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-12 col-lg-4">
                                    <a href="<?php echo e(route('category.sort', ['slug' => $item->getSlugByLanguage($lang)])); ?>"
                                        class="d-flex align-items-center p-2 border rounded">
                                        <img src="<?php echo e(asset('storage/' . $item->image)); ?>"
                                            alt="<?php echo e($item['name_' . $lang]); ?>" class="img-fluid me-3 rounded"
                                            style="width: 80px; height: 80px; object-fit: cover;">
                                        <div>
                                            <p class="mb-0 fw-bold"><?php echo e($item['name_' . $lang]); ?></p>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
    <script>
        function addToCart(productId, productName, productPrice, variantId) {
            $.ajax({
                url: `/add-to-cart`,
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    product_id: productId,
                    variant_id: variantId,
                    price: productPrice,
                    storage: 1,
                },
                success: function(response) {
                    if (response.success) {
                        updateCartCount(response.cart_count);

                        // Bootstrap toast xabarni ko'rsatish
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();
                    } else {
                        alert('Xatolik yuz berdi: ' + response.message);
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                }
            });
        }

        function updateCartCount(count) {
            document.getElementById('cart-count').innerText = count; // Updates the cart count badge
        }

        function toggleFavourite(productId) {
            $.ajax({
                url: '/toggle-favorite',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: productId
                },
                success: function(response) {
                    if (response.success) {
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();

                        // Sevimlilar sonini yangilash
                        $('#favorite-count').text(response.favorites_count);

                        // Ico'ni yangilash
                        if (response.message.includes('qo\'shildi')) {
                            $('#favourite-icon-' + productId).addClass('text-orange');
                            if (document.getElementById('favourite-icon-' + productId).classList.contains(
                                    "fa-regular")) {
                                document.getElementById('favourite-icon-' + productId).classList.remove(
                                    'fa-regular')
                                document.getElementById('favourite-icon-' + productId).classList.add('fa-solid')
                            }
                        } else {
                            $('#favourite-icon-' + productId).removeClass(
                                'text-orange'); // O'chirilganini ko'rsatish
                            if (document.getElementById('favourite-icon-' + productId).classList.contains(
                                    "fa-solid")) {
                                document.getElementById('favourite-icon-' + productId).classList.remove(
                                    'fa-solid')
                                document.getElementById('favourite-icon-' + productId).classList.add(
                                    'fa-regular')
                            }
                        }
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                }
            });
        }

        function toggleCompare(productId) {
            $.ajax({
                url: '/toggle-compare',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: productId
                },
                success: function(response) {
                    if (response.success) {
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();

                        // Sevimlilar sonini yangilash
                        $('#compare-count').text(response.compares_count); // Id bo'yicha o'zgarish

                        // Ico'ni yangilash
                        if (response.message.includes('qo\'shildi')) {
                            $('#compare-icon-' + productId).addClass(
                                'active-svg'); // Qo'shilganini ko'rsatish
                        } else {
                            $('#compare-icon-' + productId).removeClass(
                                'active-svg'); // O'chirilganini ko'rsatish
                        }
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/compare.blade.php ENDPATH**/ ?>