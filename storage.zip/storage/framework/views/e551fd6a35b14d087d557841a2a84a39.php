<?php if($paginator->hasPages()): ?>
    <ul class="pagination">
        <?php if($paginator->onFirstPage()): ?>
            <li class="paginate_button page-item previous disabled m-2" aria-disabled="true">
                <a href="#" tabindex="0" class="page-link">Previous</a>
            </li>
        <?php else: ?>
            <li class="paginate_button page-item previous m-2">
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" aria-controls="proposalList" tabindex="0"
                   class="page-link">Previous</a>
            </li>
        <?php endif; ?>
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_string($element)): ?>
                <li class="page-item disabled m-2" aria-disabled="true"><span><?php echo e($element); ?></span></li>
            <?php endif; ?>
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="paginate_button page-item active m-2" aria-current="page">
                            <a href="#" aria-controls="proposalList" tabindex="0" class="page-link"><?php echo e($page); ?></a>
                        </li>
                    <?php else: ?>
                        <li class="paginate_button page-item m-2">
                            <a href="<?php echo e($url); ?>" aria-controls="proposalList" tabindex="0"
                               class="page-link"><?php echo e($page); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($paginator->hasMorePages()): ?>
            <li class="paginate_button page-item next m-2">
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" aria-controls="proposalList" tabindex="0" class="page-link">Next</a>
            </li>
        <?php else: ?>
            <li class="paginate_button page-item next disabled m-2" aria-disabled="true">
                <a href="#" tabindex="0" class="page-link">Next</a>
            </li>
        <?php endif; ?>
    </ul>
<?php endif; ?>
<?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/vendor/pagination/custom.blade.php ENDPATH**/ ?>