<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('blogs.update', $blog->id)); ?>" method="POST" enctype="multipart/form-data" novalidate class="needs-validation" onsubmit="updateEditorContent()">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <main class="nxl-container">
            <div class="nxl-content">
                <div class="page-header">
                    <div class="page-header-left d-flex align-items-center">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Редактировать Блог</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                            <li class="breadcrumb-item">Блог</li>
                        </ul>
                    </div>
                    <div class="page-header-right ms-auto">
                        <button type="submit" class="btn btn-primary">Сохранить изменения</button>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger m-3">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Детали Блог</h5>
                                </div>
                                <div class="card-body p-4">
                                    <ul class="nav-tab-items-wrapper nav nav-justified invoice-overview-tab-item">
                                        <li class="nav-item">
                                            <a href="#uzContent" class="nav-link active" data-bs-toggle="tab" data-bs-target="#uzContent">O'zbekcha</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#enContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#enContent">English</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#ruContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#ruContent">Русский</a>
                                        </li>
                                    </ul>

                                    <div class="tab-content pt-3">
                                        <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade show <?php echo e($lang == 'uz' ? 'active' : ''); ?>" id="<?php echo e($lang); ?>Content">
                                                <div class="form-group pb-3">
                                                    <label for="title_<?php echo e($lang); ?>">Заголовок (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <input type="text" class="form-control" id="title_<?php echo e($lang); ?>" name="title_<?php echo e($lang); ?>" value="<?php echo e(old('title_' . $lang, $blog->{'title_' . $lang})); ?>" required>
                                                </div>
                                                <div class="form-group pb-3">
                                                    <label for="description_<?php echo e($lang); ?>">Oписание (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <div id="descriptionEditor_<?php echo e($lang); ?>" style="height:200px;"><?php echo old('description_' . $lang, $blog->{'description_' . $lang}); ?></div>
                                                    <input type="hidden" id="description_<?php echo e($lang); ?>" name="description_<?php echo e($lang); ?>">
                                                </div>
                                                <div class="form-group pb-3">
                                                    <label for="content_<?php echo e($lang); ?>">Контент (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <div id="editor_<?php echo e($lang); ?>" style="height:200px;"><?php echo old('content_' . $lang, $blog->{'content_' . $lang}); ?></div>
                                                    <input type="hidden" id="content_<?php echo e($lang); ?>" name="content_<?php echo e($lang); ?>">
                                                </div>
                                                <div class="form-group pb-3">
                                                    <label for="general_<?php echo e($lang); ?>">Итого (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <div id="editorGeneral_<?php echo e($lang); ?>" style="height:200px;"><?php echo old('general_' . $lang, $blog->{'general_' . $lang}); ?></div>
                                                    <input type="hidden" id="general_<?php echo e($lang); ?>" name="general_<?php echo e($lang); ?>">
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Изображение Блог</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="form-group pb-3">
                                        <label for="date">Дата:</label>
                                        <input type="date" class="form-control" id="date" name="date" value="<?php echo e(old('date', $blog->date ? \Carbon\Carbon::parse($blog->date)->format('Y-m-d') : '')); ?>">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="image">Изображение:</label>
                                        <input type="file" class="form-control" id="image" name="image">
                                        <?php if($blog->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="Current Image" class="img-thumbnail mt-2" width="200">
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </form>

    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

    <script>

        <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        var editor<?php echo e(ucfirst($lang)); ?> = new Quill('#editor_<?php echo e($lang); ?>', { theme: 'snow' });
        var descriptionEditor<?php echo e(ucfirst($lang)); ?> = new Quill('#descriptionEditor_<?php echo e($lang); ?>', { theme: 'snow' });
        var editorGeneral<?php echo e(ucfirst($lang)); ?> = new Quill('#editorGeneral_<?php echo e($lang); ?>', { theme: 'snow' });
        editor<?php echo e(ucfirst($lang)); ?>.root.innerHTML = `<?php echo old('content_' . $lang, $blog->{'content_' . $lang}); ?>`;
        descriptionEditor<?php echo e(ucfirst($lang)); ?>.root.innerHTML = `<?php echo old('description_' . $lang, $blog->{'description_' . $lang}); ?>`;
        editorGeneral<?php echo e(ucfirst($lang)); ?>.root.innerHTML = `<?php echo old('general_' . $lang, $blog->{'general_' . $lang}); ?>`;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        function updateEditorContent() {
            <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            document.getElementById('content_<?php echo e($lang); ?>').value = editor<?php echo e(ucfirst($lang)); ?>.root.innerHTML;
            document.getElementById('description_<?php echo e($lang); ?>').value = descriptionEditor<?php echo e(ucfirst($lang)); ?>.root.innerHTML;
            document.getElementById('general_<?php echo e($lang); ?>').value = editorGeneral<?php echo e(ucfirst($lang)); ?>.root.innerHTML;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/blogs/edit.blade.php ENDPATH**/ ?>