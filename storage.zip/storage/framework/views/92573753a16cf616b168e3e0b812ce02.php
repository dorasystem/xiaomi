<?php $__env->startSection('title', 'Список новостей'); ?>

<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <div class="nxl-content">
            <div class="page-header">
                <div class="page-header-left d-flex align-items-center">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Список Блоги</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                        <li class="breadcrumb-item">Блог</li>
                    </ul>
                </div>
                <div class="page-header-right ms-auto">
                    <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary">Добавить Блог</a>
                </div>
            </div>
            <div class="main-content">

                <!-- News Table -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Блог</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="">
                            <tr>
                                <th scope="col">№</th>
                                <th scope="col">Заголовок (РУ)</th>
                                <th scope="col">Дата</th>
                                <th scope="col">Изображение</th>
                                <th scope="col" class="text-end">Действия</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->title_ru); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->date)->format('d.m.Y')); ?></td>
                                    <td>
                                        <?php if($item->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="<?php echo e($item->title_en); ?>" width="50" class="img-thumbnail">
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('blogs.show', $item->id)); ?>"
                                               class="avatar-text avatar-md me-2">
                                                <i class="feather feather-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('blogs.edit', $item->id)); ?>"
                                               class="avatar-text avatar-md">
                                                <i class="feather feather-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('blogs.destroy', $item->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="border-0 bg-transparent js-delete-btn" type="submit"  onclick="return confirm('Ushbu faoliyatni o‘chirishni xohlaysizmi?')">
                                                    <a href="javascript:void(0)" class="avatar-text avatar-md" data-bs-toggle="tooltip" data-bs-trigger="hover" title="" data-bs-original-title="O'chirish" aria-label="O'chirish">
                                                        <i class="feather-trash-2"></i>
                                                    </a>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($blogs->isEmpty()): ?>
                        <div class="card-body">
                            <p class="text-center">На данный момент Блоги отсутствуют.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/blogs/index.blade.php ENDPATH**/ ?>