<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <div class="nxl-content">
            <div class="page-header">
                <div class="page-header-left d-flex align-items-center">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Добавить новое ключевое слово</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                        <li class="breadcrumb-item">Ключевые слова</li>
                        <li class="breadcrumb-item active">Новое ключевое слово</li>
                    </ul>
                </div>
                <div class="page-header-right ms-auto">
                    <a href="<?php echo e(route('keywords.index')); ?>" class="btn btn-secondary">Назад</a>
                </div>
            </div>

            <div class="main-content">
                <div class="card stretch">
                    <div class="card-header">
                        <h5 class="card-title">Добавить ключевое слово</h5>
                    </div>
                    <div class="card-body p-4">
                        <form action="<?php echo e(route('keywords.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group pb-3">
                                <label for="key">Ключевое слово:</label>
                                <input type="text" class="form-control" id="key" name="key" value="<?php echo e(old('key')); ?>" required>
                            </div>

                            <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group pb-3">
                                    <label for="<?php echo e($lang); ?>">Description (<?php echo e(strtoupper($lang)); ?>):</label>
                                    <input type="text" class="form-control" id="<?php echo e($lang); ?>" name="<?php echo e($lang); ?>"
                                           value="<?php echo e(old($lang)); ?>" required>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <button type="submit" class="btn btn-primary">Сохранить</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/keywords/create.blade.php ENDPATH**/ ?>