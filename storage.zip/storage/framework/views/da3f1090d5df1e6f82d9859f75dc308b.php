<?php $__env->startSection('title', 'Список изображений и описаний'); ?>

<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <div class="nxl-content">
            <div class="page-header">
                <div class="page-header-left d-flex align-items-center">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Список изображений и описаний</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                        <li class="breadcrumb-item">Изображения и описания</li>
                    </ul>
                </div>
                <div class="page-header-right ms-auto">
                    <a href="<?php echo e(route('desc-images.create')); ?>" class="btn btn-primary">Добавить описание изображений</a>
                </div>
            </div>

            <div class="main-content">
                <!-- Desc Images Table -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Изображения и описания</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th scope="col">№</th>
                                    <th scope="col">Изображение</th>
                                    <th scope="col">Описание</th>
                                    <th scope="col" class="">Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $descImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $descImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('storage/' . $descImage->image)); ?>" alt="Image"
                                                style="width: 50px; height: 50px; object-fit: cover;">
                                        </td>
                                        <td>
                                            <p><?php echo e(\Illuminate\Support\Str::words($descImage->description_ru ?? '', 8, '...')); ?>

                                            </p>
                                        </td>

                                        <td class="">
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('desc-images.edit', $descImage->id)); ?>"
                                                    class="avatar-text avatar-md">
                                                    <i class="feather feather-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('desc-images.destroy', $descImage->id)); ?>"
                                                    method="POST" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <div class="avatar-text avatar-md">
                                                        <button class="border-0 bg-transparent js-delete-btn" type="submit"
                                                            onclick="return confirm('Вы действительно хотите удалить это изображение?')">
                                                            <i class="  feather-trash-2"></i>
                                                        </button>
                                                    </div>

                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($descImages->isEmpty()): ?>
                        <div class="card-body">
                            <p class="text-center">На данный момент изображения и описания отсутствуют.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/desc_images/index.blade.php ENDPATH**/ ?>