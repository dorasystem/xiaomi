<?php $__env->startSection('title', 'Просмотр продукта'); ?>

<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <div class="nxl-content">
            <div class="page-header">
                <div class="page-header-left d-flex align-items-center">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Детали продукта</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Продукты</a></li>
                        <li class="breadcrumb-item">Детали продукта</li>
                    </ul>
                </div>
                <div class="page-header-right ms-auto">
                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary">Редактировать</a>
                </div>
            </div>
            <div class="main-content">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Информация о продукте</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <!-- Image -->

                            <!-- Details -->
                            <div class="col-md-8">
                                <table class="table table-borderless">
                                    <tr>
                                        <th>Название:</th>
                                        <td><?php echo e($product->name_uz); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Описание:</th>
                                        <td><?php echo (($product->description_uz)); ?></td>
                                    <tr>
                                        <th>Подарок:</th>
                                        <td><?php echo e($product->gift_name ?? 'Не указан'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Дата создания:</th>
                                        <td><?php echo e($product->created_at->format('d.m.Y H:i')); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Последнее обновление:</th>
                                        <td><?php echo e($product->updated_at->format('d.m.Y H:i')); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Изображение:</th>
                                        <td>
                                            <div class="col-md-4 text-center">
                                                <?php if($product->gift_image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $product->gift_image)); ?>"
                                                        alt="<?php echo e($product->gift_name); ?>" class="img-thumbnail"
                                                        style="max-width: 100%;">
                                                <?php else: ?>
                                                    <p class="text-muted">Изображение отсутствует</p>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer row">
                        <div class="col-sm-6">
                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger w-100"
                                    onclick="return confirm('Вы действительно хотите удалить этот продукт?')">Удалить</button>
                            </form>
                        </div>
                        <div class="col-sm-6">
                            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Назад</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/products/show.blade.php ENDPATH**/ ?>