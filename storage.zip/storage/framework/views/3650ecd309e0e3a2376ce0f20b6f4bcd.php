<?php $__env->startSection('title', 'Список вакансий'); ?>

<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <div class="nxl-content">
            <!-- Page Header -->
            <div class="page-header">
                <div class="page-header-left d-flex align-items-center">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Список вакансий</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                        <li class="breadcrumb-item">Вакансии</li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="main-content p-3">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card stretch stretch-full">
                            <div class="card-body p-0">
                                <div class="px-2 py-3">
                                    <div class="d-flex justify-content-between">
                                        <h4 class="bold">Вакансии</h4>
                                        <div class="">
                                            <div class="dataTables_filter">
                                                <a href="<?php echo e(route('vacancies.create')); ?>"
                                                   class="btn btn-sm btn-primary">Добавить</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-hover" id="vacancyList">
                                        <thead>
                                        <tr>
                                            <th>№</th>
                                            <th>Название (УЗ)</th>
                                            <th>Название (РУ)</th>
                                            <th>Название (АН)</th>
                                            <th>Изображение</th>
                                            <th class="text-end">Действия</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($vacancy->title_uz); ?></td>
                                                <td><?php echo e($vacancy->title_ru); ?></td>
                                                <td><?php echo e($vacancy->title_en); ?></td>

                                                <td>
                                                    <?php if($vacancy->image): ?>
                                                        <img src="<?php echo e(asset('storage/' . $vacancy->image)); ?>" alt="<?php echo e($vacancy->title_en); ?>" width="50">
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="hstack gap-2 justify-content-end">
                                                        <a href="<?php echo e(route('vacancies.edit', $vacancy->id)); ?>"
                                                           class="avatar-text avatar-md">
                                                            <i class="feather feather-edit-3"></i>
                                                        </a>
                                                        <form action="<?php echo e(route('vacancies.destroy', $vacancy->id)); ?>" method="POST" style="display: inline-block;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="avatar-text avatar-md" onclick="return confirm('Are you sure?')">
                                                                <i class="feather feather-trash-2"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/vacancies/index.blade.php ENDPATH**/ ?>