<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data" novalidate class="needs-validation" onsubmit="updateEditorContent()">
        <?php echo csrf_field(); ?>

        <main class="nxl-container">
            <div class="nxl-content">
                <div class="page-header">
                    <div class="page-header-left d-flex align-items-center">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Создать продукт</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                            <li class="breadcrumb-item">Продукты</li>
                        </ul>description_ru
                    </div>
                    <div class="page-header-right ms-auto">
                        <button type="submit" class="btn btn-primary">Создать</button>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger m-3">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-8 pb-5">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Детали продукта</h5>
                                </div>
                                <div class="card-body p-4">
                                    <ul class="nav-tab-items-wrapper nav nav-justified invoice-overview-tab-item">
                                        <li class="nav-item">
                                            <a href="#uzContent" class="nav-link active" data-bs-toggle="tab" data-bs-target="#uzContent">O'zbekcha</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#enContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#enContent">English</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#ruContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#ruContent">Русский</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content pt-3">
                                        <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade show <?php echo e($lang == 'uz' ? 'active' : ''); ?>" id="<?php echo e($lang); ?>Content">
                                                <div class="form-group pb-3">
                                                    <label for="name_<?php echo e($lang); ?>">Заголовок (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <input type="text" class="form-control" id="name_<?php echo e($lang); ?>" name="name_<?php echo e($lang); ?>"
                                                           value="<?php echo e(old('name_' . $lang)); ?>" required>
                                                </div>
                                                <div class="form-group pb-3">
                                                    <label for="description_<?php echo e($lang); ?>">Описание (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <div id="descriptionEditor_<?php echo e($lang); ?>" style="height:200px;"><?php echo old('description_' . $lang); ?></div>
                                                    <input type="hidden" id="description_<?php echo e($lang); ?>" name="description_<?php echo e($lang); ?>" value="<?php echo e(old('description_' . $lang)); ?>">
                                                </div>
                                                <div class="form-group pb-3">
                                                    <label for="content_<?php echo e($lang); ?>">Характеристики (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <div id="contentEditor_<?php echo e($lang); ?>" style="height:200px;"><?php echo old('content_' . $lang); ?></div>
                                                    <input type="hidden" id="content_<?php echo e($lang); ?>" name="content_<?php echo e($lang); ?>" value="<?php echo e(old('content_' . $lang)); ?>">
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                    <div id="product-forms">
                                        <div class="row px-4 pb-2 product-form">
                                            <div class="form-group pb-3 col-md-4">
                                                <label for="storage">Место хранения:</label>
                                                <select class="form-control" id="storage" name="storage[]">
                                                    <option value="null">Null</option>
                                                    <option value="2/32GB">2/32 GB</option>
                                                    <option value="4/64GB">4/64 GB</option>
                                                    <option value="6/128GB">6/128 GB</option>
                                                    <option value="8/256GB">8/256 GB</option>
                                                    <option value="12/256GB">12/256 GB</option>
                                                    <option value="12/512GB">12/512 GB</option>
                                                </select>
                                            </div>
                                            <div class="form-group pb-3 col-md-4">
                                                <label for="price">Цена:</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="price[]" value="">
                                                    <span class="input-group-text">UZS</span>
                                                </div>
                                            </div>
                                            <div class="form-group pb-3 col-md-4">
                                                <label for="discount_price">Скидочная цена:</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="discount_price[]" value="">
                                                    <span class="input-group-text">UZS</span>
                                                </div>
                                            </div>


                                            <div class="form-group pb-3 col-md-3">
                                                <label for="price_6">Цена за 6 месяцев:</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="price_6[]" value="">
                                                    <span class="input-group-text">UZS</span>
                                                </div>
                                            </div>
                                            <div class="form-group pb-3 col-md-3">
                                                <label for="price_12">Цена за 12 месяцев:</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="price_12[]" value="">
                                                    <span class="input-group-text">UZS</span>
                                                </div>
                                            </div>
                                            <div class="form-group pb-3 col-md-3">
                                                <label for="price_24">Цена за 24 месяца:</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="price_24[]" value="">
                                                    <span class="input-group-text">UZS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="button" id="add-more" class="btn btn-primary mt-3">Добавить ещё</button>
                            </div>

                        </div>
                        <div class="col-lg-4 pb-5">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Дополнительно</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="form-group pb-3">
                                        <label for="category_id">Категория:</label>
                                        <select id="category_id" name="category_id" class="form-control" required>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name_ru); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group pb-3 ">
                                        <label for="color_ru">Цвет RU:</label>
                                        <select class="form-control" id="color_ru" name="color_ru">
                                            <option value="null" <?php echo e(old('color_ru') == 'null' ? 'selected' : ''); ?>>
                                                Null
                                            </option>
                                            <option value="red" <?php echo e(old('color_ru') == 'red' ? 'selected' : ''); ?>>
                                                Красный
                                            </option> <!-- Russian for Red -->
                                            <option
                                                value="white" <?php echo e(old('color_ru') == 'white' ? 'selected' : ''); ?>>
                                                Белый
                                            </option> <!-- Russian for Green -->
                                            <option
                                                value="green" <?php echo e(old('color_ru') == 'green' ? 'selected' : ''); ?>>
                                                Зелёный
                                            </option> <!-- Russian for Green -->
                                            <option
                                                value="grey" <?php echo e(old('color_ru') == 'grey' ? 'selected' : ''); ?>>
                                                Серый
                                            </option> <!-- Russian for Green -->
                                            <option value="blue" <?php echo e(old('color_ru') == 'blue' ? 'selected' : ''); ?>>
                                                Синий
                                            </option> <!-- Russian for Blue -->
                                            <option
                                                value="black" <?php echo e(old('color_ru') == 'black' ? 'selected' : ''); ?>>
                                                Черный
                                            </option> <!-- Russian for Black -->
                                            <option
                                                value="brown" <?php echo e(old('color_ru') == 'brown' ? 'selected' : ''); ?>>
                                                Коричневый
                                            </option> <!-- Russian for Brown -->
                                        </select>
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="image">Первое изображение:</label>
                                        <input type="file" class="form-control" id="image" name="image">
                                    </div>

                                    <div class="form-group pb-3">
                                        <label for="images">Дополнительные изображения:</label>
                                        <input type="file" class="form-control" id="images" name="images[]" multiple>
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="gift_name">Подарок название:</label>
                                        <input type="text" class="form-control" id="gift_name" name="gift_name" value="<?php echo e(old('gift_name')); ?>">
                                    </div>

                                    <div class="form-group pb-3">
                                        <label for="image">Изображение Подарок:</label>
                                        <input type="file" class="form-control" id="image" name="gift_image">
                                    </div>







                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </form>

    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

    <script>

        <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        var descriptionEditor<?php echo e(ucfirst($lang)); ?> = new Quill('#descriptionEditor_<?php echo e($lang); ?>', { theme: 'snow' });
        var contentEditor<?php echo e(ucfirst($lang)); ?> = new Quill('#contentEditor_<?php echo e($lang); ?>', { theme: 'snow' });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        function updateEditorContent() {
            <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            document.getElementById('description_<?php echo e($lang); ?>').value = descriptionEditor<?php echo e(ucfirst($lang)); ?>.root.innerHTML;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            document.getElementById('content_<?php echo e($lang); ?>').value = contentEditor<?php echo e(ucfirst($lang)); ?>.root.innerHTML;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        }



        document.getElementById('add-more').addEventListener('click', function () {
            // Select the first form group to clone
            const formGroup = document.querySelector('.product-form');
            // Clone the form group
            const clone = formGroup.cloneNode(true);

            // Clear the input values in the cloned form group
            const inputs = clone.querySelectorAll('input');
            inputs.forEach(input => input.value = '');

            // Append the cloned form group to the container
            document.getElementById('product-forms').appendChild(clone);
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/products/create.blade.php ENDPATH**/ ?>