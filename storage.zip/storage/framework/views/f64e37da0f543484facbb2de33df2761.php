<?php use Illuminate\Support\Str; ?>


<?php $__env->startSection('content'); ?>
    <style>
        .slider-container {
            position: relative;
            width: 100%;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .slider-container input[type="range"] {
            -webkit-appearance: none;
            width: 100%;
            height: 5px;
            background: #ff6600;
            border-radius: 5px;
            outline: none;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            pointer-events: none;
        }

        .slider-container input[type="range"]::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 16px;
            height: 16px;
            background: #ff6600;
            border-radius: 50%;
            cursor: pointer;
            pointer-events: auto;
            position: relative;
        }

        .slider-container input[type="range"]::-moz-range-thumb {
            width: 16px;
            height: 16px;
            background: #ff6600;
            border-radius: 50%;
            cursor: pointer;
            pointer-events: auto;
        }

        .slider-container input[type="range"]::-webkit-slider-thumb:hover {
            background: #ff4500;
        }

        .slider-container input[type="range"]::-moz-range-thumb:hover {
            background: #ff4500;
        }

        .slider-track {
            position: absolute;
            height: 5px;
            background: #ff6600;
            /*z-index: -1;*/
            width: 100%;
        }

    </style>

    <main>
        <div class="container mt-4">
            <div class="d-flex align-items-center gap-3">
                <a href="/" class="text-grey fw-bold  fs-14"><?php echo app('translator')->get('home.home'); ?> / <span
                        class="text-dark"><?php echo app('translator')->get('home.products'); ?></span></a>
            </div>
            <hr />
        </div>
        <div class="productHeader bg-grey">
            <div class="container py-5 d-flex align-items-center flex-lg-row flex-column justify-content-between">
                <div class="">
                    <p><?php echo app('translator')->get('home.filter_title'); ?></p>
                    <h2 class="fw-bold fs-1">
                        <?php echo app('translator')->get('home.filter_desc'); ?>
                    </h2>
                </div>
                <div class="productbanner align-items-start gap-4 mt-5">
                    <div class="product_list d-flex align-items-center justify-content-center">
                        <img src="/assets/images/headphones.png" width="250px" alt="" />
                    </div>
                    <div class="">
                        <div class="little_product d-flex align-items-center justify-content-center">
                            <img src="/assets/images/airpods.png" width="120px" alt="" />
                        </div>
                        <div class="position-relative">
                            <img class="bottom_product border-orange" src="/assets/images/bottom_product.png" width="120px"
                                alt="" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="filterProducts container py-4">
            <div class="row">
                <div class="col-lg-3 d-lg-block d-none">
                    <div style="top:30px;" class="bg-white p-4 rounded position-sticky ">
                        <form method="GET" action="<?php echo e(route('products.filter')); ?>">
                            <div class="accordion" id="accordionPanelsStayOpenExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                        <button class="accordion-button " type="button" data-bs-toggle="collapse"
                                                data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true"
                                                aria-controls="panelsStayOpen-collapseOne">
                                            <?php echo app('translator')->get('home.category'); ?>
                                        </button>
                                    </h2>
                                    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show"
                                         aria-labelledby="panelsStayOpen-headingOne">
                                        <div class="accordion-body">
                                            <!-- 'All' checkbox -->
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" type="checkbox" id="select-all" />
                                                <label class="form-check-label" for="select-all">
                                                    <small><?php echo app('translator')->get('home.all_categories'); ?></small>
                                                </label>
                                            </div>
                                            <!-- Individual checkboxes -->
                                            <div id="category-container">
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-check mb-3 category-item" style="display: <?php echo e($index < 10 ? 'block' : 'none'); ?>">
                                                        <input class="form-check-input category-checkbox" type="checkbox" name="categories[]"
                                                               value="<?php echo e($category->id); ?>" id="category-<?php echo e($category->id); ?>" checked />
                                                        <label class="form-check-label" for="category-<?php echo e($category->id); ?>">
                                                            <small><?php echo e($category['name_' . $lang]); ?></small>
                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                            <!-- Ko'proq ko'rsatish tugmasi -->
                                            <a id="showMoreBtn" class="w-100 btn-orange2 rounded text-center mb-3 btn">Ko'proq ko'rsatish</a>


                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true"
                                                aria-controls="panelsStayOpen-collapseTwo">
                                            <?php echo app('translator')->get('home.price'); ?>
                                        </button>
                                    </h2>
                                    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse show pt-3"
                                         aria-labelledby="panelsStayOpen-headingTwo">
                                        <div class="accordion-body">
                                            <div class="range-slider">









                                                <div class="slider-container">
                                                    <div class="slider-track"></div>
                                                    <input type="range" id="rangeMin" min="0" max="40000000" value="<?php echo e(request('min_price', 1)); ?>" />
                                                    <input type="range" id="rangeMax" min="0" max="40000000" value="<?php echo e(request('max_price', 40000000)); ?>" />
                                                </div>
                                                <span id="minValue1" style="font-size: 14px">
                                                    <?php echo e(number_format(request('min_price', 1), 0, ',', ' ')); ?> so'm
                                                </span> -
                                                                                                <span id="maxValue1" style="font-size: 14px">
                                                    <?php echo e(number_format(request('max_price', 40000000), 0, ',', ' ')); ?> so'm
                                                </span>

                                                <script>
                                                    document.addEventListener("DOMContentLoaded", function () {
                                                        let rangeMin = document.getElementById("rangeMin");
                                                        let rangeMax = document.getElementById("rangeMax");
                                                        let minValue = document.getElementById("minValue1");
                                                        let maxValue = document.getElementById("maxValue1");

                                                        function formatPrice(value) {
                                                            return new Intl.NumberFormat('uz-UZ').format(Number(value)) + " so'm";
                                                        }

                                                        function updateValues() {
                                                            minValue.textContent = formatPrice(rangeMin.value);
                                                            maxValue.textContent = formatPrice(rangeMax.value);
                                                        }

                                                        rangeMin.addEventListener("input", updateValues);
                                                        rangeMax.addEventListener("input", updateValues);
                                                    });
                                                </script>




                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit"
                                    class="w-100 btn-orange rounded text-center mb-3"><?php echo app('translator')->get('home.search'); ?></button>
                            <button class="w-100 text-orange bg-transparent rounded text-center border-orange rounded py-1">
                                <a href="<?php echo e(route('products')); ?>"
                                   class="w-100 text-orange bg-transparent  text-center  py-1">
                                    <?php echo app('translator')->get('home.reset'); ?>
                                </a>
                            </button>
                        </form>
                    </div>

                </div>
                <div class="col-lg-9">
                    <div class="container">
                        <div class="d-flex gap-2">
                            <!-- Mobile Filter Modal -->
                            <form method="GET" action="<?php echo e(route('products.filter')); ?>">
                                <div class="d-lg-none d-block">
                                    <button class="btn-orange rounded mb-3" type="button" data-bs-toggle="modal"
                                        data-bs-target="#filtermodal">Filter
                                    </button>
                                    <div class="modal" id="filtermodal" tabindex="-1"
                                        aria-labelledby="filtermodalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div style="height: 650px; overflow-y: auto"
                                                class="modal-content d-flex flex-column justify-content-between">
                                                <div class="">
                                                    <div class="modal-header position-sticky top-0 bg-white z-3">
                                                        <h2 class="fw-normal"><?php echo app('translator')->get('home.all_filters'); ?></h2>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="accordion" id="accordionPanelsStayOpenExample">
                                                        <div class="accordion-item">
                                                            <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                                                <button class="accordion-button" type="button"
                                                                    data-bs-toggle="collapse"
                                                                    data-bs-target="#panelsStayOpen-collapseOne"
                                                                    aria-expanded="true"
                                                                    aria-controls="panelsStayOpen-collapseOne">
                                                                    <?php echo app('translator')->get('home.category'); ?>
                                                                </button>
                                                            </h2>
                                                            <div id="panelsStayOpen-collapseOne"
                                                                class="accordion-collapse collapse show"
                                                                aria-labelledby="panelsStayOpen-headingOne">
                                                                <div class="accordion-body text-capitalize">
                                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="form-check mb-3">
                                                                            <input class="form-check-input"
                                                                                type="checkbox" name="categories[]"
                                                                                value="<?php echo e($category->id); ?>"
                                                                                id="category-<?php echo e($category->id); ?>"
                                                                                <?php echo e(in_array($category->id, request('categories', [])) ? 'checked' : ''); ?> />
                                                                            <label class="form-check-label"
                                                                                for="category-<?php echo e($category->id); ?>">
                                                                                <small><?php echo e($category['name_' . $lang]); ?></small>
                                                                            </label>
                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="accordion-item">
                                                            <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
                                                                <button class="accordion-button" type="button"
                                                                    data-bs-toggle="collapse"
                                                                    data-bs-target="#panelsStayOpen-collapseTwo"
                                                                    aria-expanded="true"
                                                                    aria-controls="panelsStayOpen-collapseTwo">
                                                                    <?php echo app('translator')->get('home.price'); ?>
                                                                </button>
                                                            </h2>
                                                            <div id="panelsStayOpen-collapseTwo"
                                                                class="accordion-collapse collapse show pt-3"
                                                                aria-labelledby="panelsStayOpen-headingTwo">
                                                                <div class="accordion-body">
                                                                    <div class="range-slider">
                                                                        <div class="inputs">
                                                                            <input type="number" id="minValue2"
                                                                                name="min_price"
                                                                                value="<?php echo e(request('min_price', 20)); ?>"
                                                                                min="0" max="600" />
                                                                            <span>до</span>
                                                                            <input type="number" id="maxValue2"
                                                                                name="max_price"
                                                                                value="<?php echo e(request('max_price', 600)); ?>"
                                                                                min="0" max="600" />
                                                                        </div>
                                                                        <div class="slider-container">
                                                                            <div class="slider-track2"></div>
                                                                            <input type="range" id="rangeMin2"
                                                                                min="0" max="600"
                                                                                value="20" />
                                                                            <input type="range" id="rangeMax2"
                                                                                min="0" max="600"
                                                                                value="600" />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="p-3 position-sticky bottom-0 z-3 bg-white">
                                                    <!-- Submit and Reset Button in Modal -->
                                                    <button type="submit"
                                                        class="w-100 btn-orange rounded text-center mb-3"><?php echo app('translator')->get('home.search'); ?></button>
                                                    <button
                                                        class="w-100 text-orange bg-transparent rounded text-center border-orange rounded py-1">
                                                        <a href="<?php echo e(route('products')); ?>"
                                                            class="w-100 text-orange bg-transparent text-center py-1">
                                                            <?php echo app('translator')->get('home.reset'); ?>
                                                        </a>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="row">
                            <?php if(!empty($products) && $products->count()): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $cheapestVariant = $product->variants->sortBy('price')->first();
                                    ?>
                                    <div class="col-lg-4 col-md-6 mb-4">
                                        <div class="product border position-relative rounded">
                                            <div class="">
                                                <div
                                                    class="position-absolute like d-flex flex-column gap-3 justify-content-end">
                                                    <a onclick="toggleFavourite(<?php echo e($product->id); ?>)">
                                                        <i id="favourite-icon-<?php echo e($product->id); ?>"
                                                            class="fa-<?php echo e(in_array($product->id, session('favorites', [])) ? 'solid' : 'regular'); ?> fa-heart fs-4 hover-orange ps-1
                                              <?php echo e(in_array($product->id, session('favorites', [])) ? 'text-orange' : ''); ?>">
                                                        </i>
                                                    </a>
                                                    <a onclick="toggleCompare(<?php echo e($product->id); ?>)">
                                                        <svg id="compare-icon-<?php echo e($product->id); ?>"
                                                            class="hover-svg <?php echo e(in_array($product->id, session('compares', [])) ? 'active-svg' : ''); ?>"
                                                            width="30" height="20" viewBox="0 0 102 92"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <rect width="11" height="92" rx="2"
                                                                fill="#000" />
                                                            <rect x="23" y="22" width="11" height="70"
                                                                rx="2" fill="#000" />
                                                            <rect x="46" y="45" width="11" height="47"
                                                                rx="2" fill="#000" />
                                                            <rect x="69" y="23" width="11" height="69"
                                                                rx="2" fill="#000" />
                                                            <rect x="91" y="45" width="11" height="47"
                                                                rx="2" fill="#000" />
                                                        </svg>
                                                    </a>
                                                </div>
                                                <?php if($cheapestVariant): ?>
                                                    <img class="w-100 pb-4 productImage p-4"
                                                        src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="" />
                                                    <div
                                                        class="d-flex flex-column justify-content-between product-text p-4 rounded-bottom">
                                                        <div class="d-flex align-items-end gap-3 pt-2">
                                                            <?php if($cheapestVariant->discount_price): ?>
                                                                <div class="fw-bold ">
                                                                    <?php echo e(number_format($cheapestVariant->discount_price, 0, ',', ' ')); ?>

                                                                    UZS
                                                                </div>
                                                                <del class="text-grey">
                                                                    <small><?php echo e(number_format($cheapestVariant->price, 0, ',', ' ')); ?>

                                                                        UZS</small>
                                                                </del>
                                                            <?php else: ?>
                                                                <div class="fw-bold">
                                                                    <?php echo e(number_format($cheapestVariant->price, 0, ',', ' ')); ?>

                                                                    UZS
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>

                                                        <a href="<?php echo e(route('single.product', $product->slug)); ?>">
                                                            <div class="productName fw-bold">
                                                                <?php echo e(\Str::words($product['name_' . $lang], 3)); ?></div>
                                                        </a>
                                                        <a class="truncate-text" href="<?php echo e(route('single.product', $product->slug)); ?>">
                                                            <?php
                                                                // Matndan faqat birinchi <p> tegi ichidagi matnni olish
                                                                preg_match('/<p[^>]*>(.*?)<\/p>/is', $product['description_' . $lang], $matches);

                                                                // Matnni HTML teglaridan tozalash va 4 ta so'zni olish
                                                                $description = isset($matches[1]) ? Str::words(strip_tags($matches[1]), 4, '...') : '...';
                                                            ?>

                                                            <p class="text-grey"><?php echo e($description); ?></p>
                                                        </a>


                                                        <div
                                                            class="d-flex align-items-center justify-content-between w-100">
                                                            <span class="small bg-transparent px-0">
                                                                <?php echo e(number_format($cheapestVariant->price ?? $cheapestVariant->discount_price, 0, ',', ' ')); ?>


                                                                UZS <span
                                                                    class="text-orange"><?php echo app('translator')->get('home.incash'); ?></span></span>
                                                            <span class="px-2 productmonth-border small text-grey">
                                                                <?php echo e(number_format($cheapestVariant->price_12, 0, ',', ' ')); ?>

                                                                UZS/<?php echo app('translator')->get('home.month'); ?></span>
                                                        </div>
                                                        <div class="d-flex gap-4 mt-3">
                                                            <a class="border-orange bg-transparent rounded p-1 px-3 add-to-cart-btn"
                                                               href="javascript:void(0);" type="button"
                                                               onclick="addToCart(this, <?php echo e($product->id); ?>, '<?php echo e($product['name_' . $lang]); ?>', <?php echo e($cheapestVariant->discount_price ?? $cheapestVariant->price); ?>, <?php echo e($cheapestVariant->id); ?>)">
                                                                <img src="/assets/icons/shopping-cart.svg" alt="Add to cart" />
                                                            </a>

                                                            <button data-bs-toggle="modal" data-bs-target="#largeModal"
                                                                class="btn-orange rounded w-100 d-flex align-items-center gap-2 justify-content-center"
                                                                data-product-id="<?php echo e($product->id); ?>"
                                                                data-product-name="<?php echo e($product['name_' . $lang]); ?>"
                                                                data-product-price="<?php echo e($cheapestVariant->discount_price ?: $cheapestVariant->price); ?>"
                                                                data-product-image="<?php echo e(asset('storage/' . $product->image)); ?>">
                                                                <span><?php echo app('translator')->get('home.buy_now'); ?></span>
                                                            </button>

                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php if (isset($component)) { $__componentOriginal87286750868bd5ed726991ca65f5034f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87286750868bd5ed726991ca65f5034f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page.not-found','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page.not-found'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87286750868bd5ed726991ca65f5034f)): ?>
<?php $attributes = $__attributesOriginal87286750868bd5ed726991ca65f5034f; ?>
<?php unset($__attributesOriginal87286750868bd5ed726991ca65f5034f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87286750868bd5ed726991ca65f5034f)): ?>
<?php $component = $__componentOriginal87286750868bd5ed726991ca65f5034f; ?>
<?php unset($__componentOriginal87286750868bd5ed726991ca65f5034f); ?>
<?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <?php echo e($products->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
            <div class="searchProductBanner text-white rounded-3 my-4 py-lg-4 px-lg-5 p-3">
                <h1 class="text-center"><?php echo app('translator')->get('home.message_title'); ?></h1>
                <p class="text-center"><?php echo app('translator')->get('home.message_desc'); ?></p>
                <div class="messageInputs p-4 rounded-4 container">
                    <form class="row align-items-center" action="<?php echo e(route('orders.store.form')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="col-lg-3 col-md-6 mb-lg-0 mb-3">
                            <input class="form-control focus_none py-3" placeholder="<?php echo app('translator')->get('home.message_input1'); ?>" type="text" required
                                name="message" />
                        </div>
                        <div class="col-lg-3 col-md-6 mb-lg-0 mb-3">
                            <input class="form-control focus_none py-3" placeholder="<?php echo app('translator')->get('home.message_input2'); ?>" type="text" required
                                name="first_name" />
                        </div>
                        <div class="col-lg-3 col-md-6 mb-lg-0 mb-3">
                            <input class="form-control focus_none py-3"
                                   placeholder="+998 __ ___ ___ ___"
                                   type="tel"
                                   name="phone"
                                   required
                                   pattern="^\+\d{7,}$"
                                   title="Номер телефона должен содержать не менее 7 цифр"
                            />
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <button class="btn-orange rounded px-5 py-3 w-100" type="submit"><?php echo app('translator')->get('home.send'); ?></button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </main>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

    <script>
        function addToCart(button, productId, productName, productPrice, variantId) {
            // Tugmaga loading klassini qo‘shish
            button.classList.add("loading");

            $.ajax({
                url: `/add-to-cart`,
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    product_id: productId,
                    variant_id: variantId,
                    price: productPrice,
                    storage: 1,
                },
                success: function(response) {
                    if (response.success) {
                        updateCartCount(response.cart_count);

                        // Bootstrap toast xabarni ko'rsatish
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();
                    } else {
                        alert('Xatolik yuz berdi: ' + response.message);
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                },
                complete: function() {
                    // 1 soniyadan keyin loading klassini olib tashlash
                    setTimeout(() => {
                        button.classList.remove("loading");
                    }, 1000); // 1000ms = 1 sekund
                }
            });
        }



        function updateCartCount(count) {
            document.getElementById('cart-count').innerText = count; // Updates the cart count badge
        }

        function toggleFavourite(productId) {
            $.ajax({
                url: '/toggle-favorite',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: productId
                },
                success: function(response) {
                    if (response.success) {
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();

                        // Sevimlilar sonini yangilash
                        $('#favorite-count').text(response.favorites_count);

                        // Ico'ni yangilash
                        if (response.message.includes('qo\'shildi')) {
                            $('#favourite-icon-' + productId).addClass('text-orange');
                            if (document.getElementById('favourite-icon-' + productId).classList.contains(
                                    "fa-regular")) {
                                document.getElementById('favourite-icon-' + productId).classList.remove(
                                    'fa-regular')
                                document.getElementById('favourite-icon-' + productId).classList.add('fa-solid')
                            }
                        } else {
                            $('#favourite-icon-' + productId).removeClass(
                                'text-orange'); // O'chirilganini ko'rsatish
                            if (document.getElementById('favourite-icon-' + productId).classList.contains(
                                    "fa-solid")) {
                                document.getElementById('favourite-icon-' + productId).classList.remove(
                                    'fa-solid')
                                document.getElementById('favourite-icon-' + productId).classList.add(
                                    'fa-regular')
                            }
                        }
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                }
            });
        }

        function toggleCompare(productId) {
            $.ajax({
                url: '/toggle-compare',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: productId
                },
                success: function(response) {
                    if (response.success) {
                        const toastBody = document.querySelector('#liveToast .toast-body');
                        toastBody.textContent = response.message;

                        const toastElement = document.getElementById('liveToast');
                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();

                        // Sevimlilar sonini yangilash
                        $('#compare-count').text(response.compares_count); // Id bo'yicha o'zgarish

                        // Ico'ni yangilash
                        if (response.message.includes('qo\'shildi')) {
                            $('#compare-icon-' + productId).addClass(
                                'active-svg'); // Qo'shilganini ko'rsatish
                        } else {
                            $('#compare-icon-' + productId).removeClass(
                                'active-svg'); // O'chirilganini ko'rsatish
                        }
                    }
                },
                error: function(xhr) {
                    alert('Xatolik yuz berdi: ' + xhr.responseText);
                }
            });
        }
        document.addEventListener("DOMContentLoaded", function () {
            const selectAllCheckbox = document.getElementById("select-all");
            const categoryCheckboxes = document.querySelectorAll(".category-checkbox");

            // Select all checkboxes when "All" is checked
            selectAllCheckbox.addEventListener("change", function () {
                categoryCheckboxes.forEach((checkbox) => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });

            // If any individual checkbox is unchecked, uncheck "All"
            categoryCheckboxes.forEach((checkbox) => {
                checkbox.addEventListener("change", function () {
                    if (!checkbox.checked) {
                        selectAllCheckbox.checked = false;
                    } else if (
                        Array.from(categoryCheckboxes).every((cb) => cb.checked)
                    ) {
                        selectAllCheckbox.checked = true;
                    }
                });
            });

            // Check all checkboxes on page load
            selectAllCheckbox.checked = true;
            categoryCheckboxes.forEach((checkbox) => {
                checkbox.checked = true;
            });
        });

    </script>

    <style>
        .btn-orange2 {
            background-color: #ff6600;
            color: white;
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 5px;
            border: none;
            transition: 0.3s;
        }

        .btn-orange2:hover {
            background-color: #e65c00;
        }

    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            let hiddenCategories = document.querySelectorAll(".category-item");
            let showMoreBtn = document.getElementById("showMoreBtn");
            let visibleCount = 10; // Boshlang'ich ko'rsatilgan kategoriya soni

            showMoreBtn.addEventListener("click", function () {
                let nextVisibleCount = visibleCount + 10;
                let foundHidden = false;

                hiddenCategories.forEach((item, index) => {
                    if (index >= visibleCount && index < nextVisibleCount) {
                        item.style.display = "block";
                        foundHidden = true;
                    }
                });

                visibleCount = nextVisibleCount;
                if (!foundHidden) {
                    showMoreBtn.style.display = "none";
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/pages/page-products.blade.php ENDPATH**/ ?>