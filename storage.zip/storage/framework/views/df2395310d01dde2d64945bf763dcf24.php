<?php $__env->startSection('title', 'Детали варианта'); ?>

<?php $__env->startSection('content'); ?>
    <main class="nxl-container">
        <div class="nxl-content">
            <div class="page-header">
                <div class="page-header-left d-flex align-items-center">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Детали варианта</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('variants.index')); ?>">Варианты</a></li>
                        <li class="breadcrumb-item active">Детали варианта</li>
                    </ul>
                </div>
            </div>
            <div class="main-content">

                <!-- Variant Details -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Информация о варианте</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <strong>Продукт:</strong>
                                    <p><?php echo e($variant->product->name_uz ?? 'Без продукта'); ?></p>
                                </div>
                                <div class="mb-3">
                                    <strong>Место хранения:</strong>
                                    <p><?php echo e($variant->storage); ?></p>
                                </div>
                                <div class="mb-3">
                                    <strong>RAM:</strong>
                                    <p><?php echo e($variant->ram); ?></p>
                                </div>
                                <div class="mb-3">
                                    <strong>Цена:</strong>
                                    <p><?php echo e($variant->price); ?> UZS</p>
                                </div>
                                <div class="mb-3">
                                    <strong>Цвет:</strong>
                                    <p><?php echo e($variant->color); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <strong>Изображение:</strong>
                                    <?php if($variant->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $variant->image)); ?>" alt="<?php echo e($variant->product->name_uz); ?>" class="img-fluid">
                                    <?php else: ?>
                                        <p>Изображение не доступно</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('variants.index')); ?>" class="btn btn-secondary">Назад</a>
                        <a href="<?php echo e(route('variants.edit', $variant->id)); ?>" class="btn btn-primary">Редактировать</a>
                        <form action="<?php echo e(route('variants.destroy', $variant->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger" type="submit" onclick="return confirm('Вы действительно хотите удалить этот вариант?')">Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/variants/show.blade.php ENDPATH**/ ?>