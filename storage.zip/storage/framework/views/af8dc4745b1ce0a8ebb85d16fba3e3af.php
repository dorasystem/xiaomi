<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('stores.update', $store->id)); ?>" method="POST" enctype="multipart/form-data" novalidate class="needs-validation">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <main class="nxl-container">
            <div class="nxl-content">
                <div class="page-header">
                    <div class="page-header-left d-flex align-items-center">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Edit Store</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">Stores</li>
                        </ul>
                    </div>
                    <div class="page-header-right ms-auto">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger m-3">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Store Details</h5>
                                </div>
                                <div class="card-body p-4">
                                    <ul class="nav-tab-items-wrapper nav nav-justified">
                                        <li class="nav-item">
                                            <a href="#uzContent" class="nav-link active" data-bs-toggle="tab" data-bs-target="#uzContent">O'zbekcha</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#enContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#enContent">English</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#ruContent" class="nav-link" data-bs-toggle="tab" data-bs-target="#ruContent">Русский</a>
                                        </li>
                                    </ul>

                                    <div class="tab-content pt-3">
                                        <?php $__currentLoopData = ['uz', 'en', 'ru']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade show <?php echo e($lang == 'uz' ? 'active' : ''); ?>" id="<?php echo e($lang); ?>Content">
                                                <div class="form-group pb-3">
                                                    <label for="title_<?php echo e($lang); ?>">Title (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <input type="text" class="form-control" id="title_<?php echo e($lang); ?>" name="title_<?php echo e($lang); ?>"
                                                           value="<?php echo e(old('title_' . $lang, $store['title_' . $lang])); ?>" required>
                                                </div>
                                                <div class="form-group pb-3">
                                                    <label for="address_<?php echo e($lang); ?>">Address (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <input type="text" class="form-control" id="address_<?php echo e($lang); ?>" name="address_<?php echo e($lang); ?>"
                                                           value="<?php echo e(old('address_' . $lang, $store['address_' . $lang])); ?>" required>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Store Image</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="form-group pb-3">
                                        <label for="phone_1">Phone 1:</label>
                                        <input type="text" class="form-control" id="phone_1" name="phone_1" value="<?php echo e(old('phone_1', $store->phone_1)); ?>">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="phone_2">Phone 2:</label>
                                        <input type="text" class="form-control" id="phone_2" name="phone_2" value="<?php echo e(old('phone_2', $store->phone_2)); ?>">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="email">Email:</label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', $store->email)); ?>">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="latitude">Latitude:</label>
                                        <input type="text" class="form-control" id="latitude" name="latitude" value="<?php echo e(old('latitude', $store->latitude)); ?>">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="longitude">Longitude:</label>
                                        <input type="text" class="form-control" id="longitude" name="longitude" value="<?php echo e(old('longitude', $store->longitude)); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/stores/edit.blade.php ENDPATH**/ ?>