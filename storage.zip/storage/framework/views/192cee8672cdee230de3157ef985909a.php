<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('vacancies.store')); ?>" method="POST" enctype="multipart/form-data" novalidate class="needs-validation" onsubmit="updateEditorContent()">
        <?php echo csrf_field(); ?>

        <main class="nxl-container">
            <div class="nxl-content">
                <div class="page-header">
                    <div class="page-header-left d-flex align-items-center">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Создать вакансию</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Главная</a></li>
                            <li class="breadcrumb-item">Вакансии</li>
                        </ul>
                    </div>
                    <div class="page-header-right ms-auto">
                        <button type="submit" class="btn btn-sm btn-primary">Создать</button>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger m-3">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Детали вакансии</h5>
                                </div>
                                <div class="card-body p-4">
                                    <ul class="nav-tab-items-wrapper nav nav-justified invoice-overview-tab-item">
                                        <li class="nav-item">
                                            <a href="javascript:void(0);" class="nav-link active" data-bs-toggle="tab" data-bs-target="#uzContent">O'zbekcha</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="javascript:void(0);" class="nav-link" data-bs-toggle="tab" data-bs-target="#enContent">English</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="javascript:void(0);" class="nav-link" data-bs-toggle="tab" data-bs-target="#ruContent">Русский</a>
                                        </li>
                                    </ul>

                                    <div class="tab-content pt-3">
                                        <?php $__currentLoopData = ['uz' => 'O\'zbekcha', 'en' => 'English', 'ru' => 'Русский']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade show <?php echo e($loop->first ? 'active' : ''); ?>" id="<?php echo e($lang); ?>Content">
                                                <div class="form-group pb-3">
                                                    <label for="name_<?php echo e($lang); ?>">Название (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <input type="text" class="form-control" id="name_<?php echo e($lang); ?>" name="name_<?php echo e($lang); ?>" value="<?php echo e(old('name_' . $lang)); ?>" required>
                                                </div>

                                                <div class="form-group pb-3">
                                                    <label for="title_<?php echo e($lang); ?>">Заголовок (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <input type="text" class="form-control" id="title_<?php echo e($lang); ?>" name="title_<?php echo e($lang); ?>" value="<?php echo e(old('title_' . $lang)); ?>" required>
                                                </div>

                                                <div class="form-group pb-3">
                                                    <label for="content_<?php echo e($lang); ?>">Содержимое (<?php echo e(strtoupper($lang)); ?>):</label>
                                                    <div id="editor_<?php echo e($lang); ?>" style="height:400px;"></div>
                                                    <input type="hidden" id="text_<?php echo e($lang); ?>" name="content_<?php echo e($lang); ?>">
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Изображение вакансии</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="form-group pb-3">
                                        <label for="image">Изображение:</label>
                                        <input type="file" class="form-control" id="image" name="image">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="date">Дата:</label>
                                        <input type="date" class="form-control" id="date" name="date" value="<?php echo e(old('date')); ?>">
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="status">Статус:</label>
                                        <select class="form-control" id="status" name="status">
                                            <option value="active" <?php echo e(old('status') == 'active' ? 'selected' : ''); ?>>Активный</option>
                                            <option value="inactive" <?php echo e(old('status') == 'inactive' ? 'selected' : ''); ?>>Неактивный</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </form>

    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

    <script>
        var editors = {
            'uz': new Quill('#editor_uz', { theme: 'snow' }),
            'en': new Quill('#editor_en', { theme: 'snow' }),
            'ru': new Quill('#editor_ru', { theme: 'snow' })
        };

        function updateEditorContent() {
            for (const [lang, editor] of Object.entries(editors)) {
                document.getElementById('text_' + lang).value = editor.root.innerHTML;
            }
        }

        document.querySelector('form').addEventListener('submit', function(event){
            updateEditorContent();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/vacancies/create.blade.php ENDPATH**/ ?>