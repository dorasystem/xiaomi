<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('orders.update', $order->id)); ?>" method="POST" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <main class="nxl-container">
            <div class="nxl-content">
                <div class="page-header">
                    <div class="page-header-left d-flex align-items-center">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Редактировать заказ</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>">Главная</a></li>
                            <li class="breadcrumb-item">Заказы</li>
                        </ul>
                    </div>
                    <div class="page-header-right ms-auto">
                        <button type="submit" class="btn btn-primary">Сохранить изменения</button>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger m-3">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Детали заказа</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="form-group pb-3">
                                        <label for="first_name">Имя:</label>
                                        <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e(old('first_name', $order->first_name)); ?>" required>
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="last_name">Фамилия:</label>
                                        <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo e(old('last_name', $order->last_name)); ?>" required>
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="email">Email:</label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', $order->email)); ?>" required>
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="phone">Телефон:</label>
                                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone', $order->phone)); ?>" required>
                                    </div>
                                    <div class="form-group pb-3">
                                        <label for="message">Сообщение:</label>
                                        <textarea class="form-control" id="message" name="message" rows="4"><?php echo e(old('message', $order->message)); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card stretch">
                                <div class="card-header">
                                    <h5 class="card-title">Товары в заказе</h5>
                                </div>
                                <div class="card-body p-4">
                                    <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group pb-3">
                                            <label>Продукт:</label>
                                            <p class="form-control-plaintext"><?php echo e($item->product->name_ru); ?></p>
                                        </div>
                                        <div class="form-group pb-3">
                                            <label>Количество:</label>
                                            <input type="number" class="form-control" name="items[<?php echo e($item->id); ?>][quantity]" value="<?php echo e(old('items.' . $item->id . '.quantity', $item->quantity)); ?>" required>
                                        </div>
                                        <div class="form-group pb-3">
                                            <label>Цена:</label>
                                            <input type="text" class="form-control" name="items[<?php echo e($item->id); ?>][price]" value="<?php echo e(old('items.' . $item->id . '.price', $item->price)); ?>" required>
                                        </div>
                                        <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nazarbek/server/XIAOMI.UZ/resources/views/admin/orders/edit.blade.php ENDPATH**/ ?>